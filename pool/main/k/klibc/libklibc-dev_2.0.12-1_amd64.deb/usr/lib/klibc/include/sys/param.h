/*
 * sys/param.h
 */

#ifndef _SYS_PARAM_H
#define _SYS_PARAM_H

#include <limits.h>
#include <linux/param.h>

#endif				/* _SYS_PARAM_H */
