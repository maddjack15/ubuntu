/*
 *
 * Architecture-specific signal definitions
 *
 */

#ifndef _KLIBC_ARCHSIGNAL_H
#define _KLIBC_ARCHSIGNAL_H

/* The in-kernel headers for i386 got clean up, use them. */

#include <linux/signal.h>

#endif
