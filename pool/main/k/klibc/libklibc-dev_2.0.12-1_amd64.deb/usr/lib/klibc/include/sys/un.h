/*
 * <sys/un.h>
 */

#ifndef _SYS_UN_H
#define _SYS_UN_H

#include <sys/socket.h>
#include <linux/un.h>

#endif				/* _SYS_UN_H */
