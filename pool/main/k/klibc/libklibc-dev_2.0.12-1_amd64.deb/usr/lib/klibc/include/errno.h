/*
 * errno.h
 */

#ifndef _ERRNO_H
#define _ERRNO_H

#include <klibc/extern.h>
#include <asm/errno.h>

__extern int errno;

#endif /* _ERRNO_H */
