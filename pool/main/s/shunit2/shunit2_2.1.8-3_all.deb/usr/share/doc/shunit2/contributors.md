The original author of shunit2 is Kate Ward. The following people have
contributed in some way or another to shunit2.

- [Alex Harvey](https://github.com/alexharv074)
- Bryan Larsen
- [David Acacio](https://github.com/dacacioa)
- Kevin Van Horn
- [Maciej Bliziński](https://github.com/automatthias)
- Mario Sparada
- Mathias Goldau
- Richard Jensen
- Rob Holland
- Rocky Bernstein
- [rugk](https://github.com/rugk)
- wood4321 (of code.google.com)
