#define OSS_COMPILE_DATE "201502111816"
#define osdev_create osdev_create_201502111816
