/*
 * Automatically generated file - do not edit.
 */
#include <oss_config.h>

#define DRIVER_NAME	oss_sbxfi
#define DRIVER_NICK	"oss_sbxfi"
#define DRIVER_STR_INFO	oss_sbxfi_str_info
#define DRIVER_ATTACH	oss_sbxfi_attach
#define DRIVER_DETACH	oss_sbxfi_detach
#define DRIVER_TYPE	DRV_PCI

extern int DRIVER_ATTACH(oss_device_t *ossdev);
extern int DRIVER_DETACH(oss_device_t *ossdev);
