/*
 * Automatically generated file - do not edit.
 */
#define DRIVER_NAME	oss_midimix
#define DRIVER_NICK	"oss_midimix"
#define DRIVER_PURPOSE	"MIDI mixer pseudo device."
#define DRIVER_STR_INFO	oss_midimix_str_info
#define DRIVER_ATTACH	oss_midimix_attach
#define DRIVER_DETACH	oss_midimix_detach
#define DRIVER_TYPE	DRV_VIRTUAL

#include "module.inc"



