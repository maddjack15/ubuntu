/*
 * Automatically generated file - do not edit.
 */
#include <oss_config.h>

#define DRIVER_NAME	oss_userdev
#define DRIVER_NICK	"oss_userdev"
#define DRIVER_STR_INFO	oss_userdev_str_info
#define DRIVER_ATTACH	oss_userdev_attach
#define DRIVER_DETACH	oss_userdev_detach
#define DRIVER_TYPE	DRV_VIRTUAL

extern int DRIVER_ATTACH(oss_device_t *ossdev);
extern int DRIVER_DETACH(oss_device_t *ossdev);
