/*
 * Automatically generated file - do not edit.
 */
#include <oss_config.h>

#define DRIVER_NAME	lynxone
#define DRIVER_NICK	"lynxone"
#define DRIVER_STR_INFO	lynxone_str_info
#define DRIVER_ATTACH	lynxone_attach
#define DRIVER_DETACH	lynxone_detach
#define DRIVER_TYPE	DRV_PCI

extern int DRIVER_ATTACH(oss_device_t *ossdev);
extern int DRIVER_DETACH(oss_device_t *ossdev);
