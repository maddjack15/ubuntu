/*
 * Automatically generated file - do not edit.
 */
#include <oss_config.h>

#define DRIVER_NAME	oss_audioloop
#define DRIVER_NICK	"oss_audioloop"
#define DRIVER_STR_INFO	oss_audioloop_str_info
#define DRIVER_ATTACH	oss_audioloop_attach
#define DRIVER_DETACH	oss_audioloop_detach
#define DRIVER_TYPE	DRV_VIRTUAL

extern int DRIVER_ATTACH(oss_device_t *ossdev);
extern int DRIVER_DETACH(oss_device_t *ossdev);
