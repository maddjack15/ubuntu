/*
 * Automatically generated file - do not edit.
 */
#include <oss_config.h>

#define DRIVER_NAME	oss_emu10k1x
#define DRIVER_NICK	"oss_emu10k1x"
#define DRIVER_STR_INFO	oss_emu10k1x_str_info
#define DRIVER_ATTACH	oss_emu10k1x_attach
#define DRIVER_DETACH	oss_emu10k1x_detach
#define DRIVER_TYPE	DRV_PCI

extern int DRIVER_ATTACH(oss_device_t *ossdev);
extern int DRIVER_DETACH(oss_device_t *ossdev);
