/*
 * Automatically generated file - do not edit.
 */
#include <oss_config.h>

#define DRIVER_NAME	oss_usb
#define DRIVER_NICK	"oss_usb"
#define DRIVER_STR_INFO	oss_usb_str_info
#define DRIVER_ATTACH	oss_usb_attach
#define DRIVER_DETACH	oss_usb_detach
#define DRIVER_TYPE	DRV_USB

extern int DRIVER_ATTACH(oss_device_t *ossdev);
extern int DRIVER_DETACH(oss_device_t *ossdev);
