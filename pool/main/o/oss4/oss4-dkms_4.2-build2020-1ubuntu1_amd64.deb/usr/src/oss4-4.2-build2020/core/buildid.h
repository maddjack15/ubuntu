#define OSS_BUILD_ID "2020"
#define __OPENOSS__
#define OSS_LICENSE "GPL"
