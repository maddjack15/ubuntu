/*
 * Automatically generated file - do not edit.
 */
#include <oss_config.h>

#define DRIVER_NAME	oss_via823x
#define DRIVER_NICK	"oss_via823x"
#define DRIVER_STR_INFO	oss_via823x_str_info
#define DRIVER_ATTACH	oss_via823x_attach
#define DRIVER_DETACH	oss_via823x_detach
#define DRIVER_TYPE	DRV_PCI

extern int DRIVER_ATTACH(oss_device_t *ossdev);
extern int DRIVER_DETACH(oss_device_t *ossdev);
