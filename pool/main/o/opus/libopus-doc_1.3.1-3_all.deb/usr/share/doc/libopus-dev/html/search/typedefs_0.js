var searchData=
[
  ['opus_5fint16_0',['opus_int16',['../opus__types_8h.html#acc9ed7cf60479eb81f9648c6ec27dc26',1,'opus_types.h']]],
  ['opus_5fint32_1',['opus_int32',['../opus__types_8h.html#aa4d309d6f80b99dbabebc8f98879ab9a',1,'opus_types.h']]],
  ['opus_5fuint16_2',['opus_uint16',['../opus__types_8h.html#a0ab2b1deead8e222cfc659cd855bd8d0',1,'opus_types.h']]],
  ['opus_5fuint32_3',['opus_uint32',['../opus__types_8h.html#a643eaaadb9ef6cd44308e0299d8cd8ce',1,'opus_types.h']]],
  ['opuscustomdecoder_4',['OpusCustomDecoder',['../group__opus__custom.html#gacae60f89c5ce7aeea69503451b9e2e6f',1,'opus_custom.h']]],
  ['opuscustomencoder_5',['OpusCustomEncoder',['../group__opus__custom.html#ga7abe6a7afc599667950251c987feb439',1,'opus_custom.h']]],
  ['opuscustommode_6',['OpusCustomMode',['../group__opus__custom.html#gaf33847c711195b9edef896b73c96ec4f',1,'opus_custom.h']]],
  ['opusdecoder_7',['OpusDecoder',['../group__opus__decoder.html#ga401d8579958d36094715a6b90cd159a6',1,'opus.h']]],
  ['opusencoder_8',['OpusEncoder',['../group__opus__encoder.html#gaf461a3ef2f10c2fe8b994a176f06c9bd',1,'opus.h']]],
  ['opusmsdecoder_9',['OpusMSDecoder',['../group__opus__multistream.html#gad3497495deb9a8ace82e76cd4f93e0e4',1,'opus_multistream.h']]],
  ['opusmsencoder_10',['OpusMSEncoder',['../group__opus__multistream.html#gae5826674d142fc873ebc1d781c507dd7',1,'opus_multistream.h']]],
  ['opusrepacketizer_11',['OpusRepacketizer',['../group__opus__repacketizer.html#ga1f85070a64bcbf5bf24f5ccb80323e7b',1,'opus.h']]]
];
