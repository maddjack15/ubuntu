var searchData=
[
  ['decoder_20related_20ctls_0',['Decoder related CTLs',['../group__opus__decoderctls.html',1,'']]]
];
