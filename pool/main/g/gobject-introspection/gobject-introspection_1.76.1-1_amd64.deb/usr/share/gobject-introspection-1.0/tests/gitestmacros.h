#ifndef __GITESTMACROS_H__
#define __GITESTMACROS_H__

#ifndef _GI_EXTERN
#define _GI_EXTERN extern
#endif

#define _GI_TEST_EXTERN _GI_EXTERN

#endif
