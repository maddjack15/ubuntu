var searchData=
[
  ['gr_5fattrcode_0',['gr_attrCode',['../Segment_8h.html#a601db47be69ba70d640815ec4b352d57',1,'Segment.h']]],
  ['gr_5fbidirtl_1',['gr_bidirtl',['../Segment_8h.html#a50b8217fbbd40f39cfe1016e205a4606',1,'Segment.h']]],
  ['gr_5fbreak_5fweight_2',['gr_break_weight',['../Segment_8h.html#a580da4ff0708003f95941b3d7b2b8741',1,'Segment.h']]],
  ['gr_5fencform_3',['gr_encform',['../Types_8h.html#a65f9281fae24ef6edd67116fe7694d38',1,'Types.h']]],
  ['gr_5fface_5foptions_4',['gr_face_options',['../Font_8h.html#a24ab1a7d43d001814e14fb5701573e60',1,'Font.h']]],
  ['gr_5fjustflags_5',['gr_justFlags',['../Segment_8h.html#af3576c699b177b0bbffd80b42553c30c',1,'Segment.h']]],
  ['gr_5fspace_5fcontextuals_6',['gr_space_contextuals',['../structgr__faceinfo.html#a29c70ff251b3a938b849e37cc5ab5b46',1,'gr_faceinfo']]],
  ['grlogmask_7',['GrLogMask',['../Log_8h.html#aaa8fbca84fe1747170d78750625dd8ec',1,'Log.h']]]
];
