var searchData=
[
  ['line_5fends_0',['line_ends',['../structgr__faceinfo.html#ae1a39b976c35df1ae0a615f827bbe525',1,'gr_faceinfo']]]
];
