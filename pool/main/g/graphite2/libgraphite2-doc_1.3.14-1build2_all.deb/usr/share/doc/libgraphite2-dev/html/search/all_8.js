var searchData=
[
  ['segment_2eh_0',['Segment.h',['../Segment_8h.html',1,'']]],
  ['size_1',['size',['../structgr__face__ops.html#a854352f53b148adc24983a58a1866d66',1,'gr_face_ops::size()'],['../structgr__font__ops.html#a854352f53b148adc24983a58a1866d66',1,'gr_font_ops::size()']]],
  ['space_5fcontextuals_2',['space_contextuals',['../structgr__faceinfo.html#a01e1c8b1f8a7ef0f9effc0fb2c35fb07',1,'gr_faceinfo']]]
];
