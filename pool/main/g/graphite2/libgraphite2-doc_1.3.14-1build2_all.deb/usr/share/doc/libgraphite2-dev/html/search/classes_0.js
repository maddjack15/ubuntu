var searchData=
[
  ['gr_5fface_5fops_0',['gr_face_ops',['../structgr__face__ops.html',1,'']]],
  ['gr_5ffaceinfo_1',['gr_faceinfo',['../structgr__faceinfo.html',1,'']]],
  ['gr_5ffont_5fops_2',['gr_font_ops',['../structgr__font__ops.html',1,'']]]
];
