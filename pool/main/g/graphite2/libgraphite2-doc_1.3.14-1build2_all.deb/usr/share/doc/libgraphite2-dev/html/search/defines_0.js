var searchData=
[
  ['gr2_5fapi_0',['GR2_API',['../Types_8h.html#ab23e4d8c7c3feff76f3b8ac9e9c71354',1,'Types.h']]],
  ['gr2_5fdeprecated_5fapi_1',['GR2_DEPRECATED_API',['../Types_8h.html#a83506e8327184bc1d3daccf33659c49a',1,'Types.h']]],
  ['gr2_5fversion_5fbugfix_2',['GR2_VERSION_BUGFIX',['../Font_8h.html#a1c00b330b71c0993cdb6805f54436474',1,'Font.h']]],
  ['gr2_5fversion_5fmajor_3',['GR2_VERSION_MAJOR',['../Font_8h.html#a62dc7c28dadb9984e023bdffc6b19efa',1,'Font.h']]],
  ['gr2_5fversion_5fminor_4',['GR2_VERSION_MINOR',['../Font_8h.html#a2fd949236035a41354166785e1949614',1,'Font.h']]]
];
