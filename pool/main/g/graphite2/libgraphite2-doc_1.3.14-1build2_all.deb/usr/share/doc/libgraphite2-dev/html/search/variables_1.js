var searchData=
[
  ['get_5ftable_0',['get_table',['../structgr__face__ops.html#a69f06b79e5945dedd174693f33b0fb70',1,'gr_face_ops']]],
  ['glyph_5fadvance_5fx_1',['glyph_advance_x',['../structgr__font__ops.html#a48395f186fa64e70eda43321e3bf146c',1,'gr_font_ops']]],
  ['glyph_5fadvance_5fy_2',['glyph_advance_y',['../structgr__font__ops.html#a6781dcb7c0b41fecc2198e78e00a0d34',1,'gr_font_ops']]]
];
