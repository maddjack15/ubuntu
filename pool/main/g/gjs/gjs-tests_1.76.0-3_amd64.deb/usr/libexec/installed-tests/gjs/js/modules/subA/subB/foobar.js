// SPDX-License-Identifier: MIT OR LGPL-2.0-or-later
// SPDX-FileCopyrightText: 2008 litl, LLC

// simple test module (used by testImporter.js)

/* exported bar, foo */

var foo = 'This is foo';
var bar = 'This is bar';
