/* exported getCount */
// SPDX-License-Identifier: MIT OR LGPL-2.0-or-later
// SPDX-FileCopyrightText: 2008 Red Hat, Inc.

const A = imports.mutualImport.a;

function getCount() {
    return A.getCount();
}

