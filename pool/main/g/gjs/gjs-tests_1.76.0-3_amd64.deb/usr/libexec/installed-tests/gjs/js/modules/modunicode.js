/* exported uval */
// SPDX-License-Identifier: MIT OR LGPL-2.0-or-later
// SPDX-FileCopyrightText: 2012 Red Hat, Inc.

// This file is written in UTF-8.

var uval = 'const ♥ utf8';
