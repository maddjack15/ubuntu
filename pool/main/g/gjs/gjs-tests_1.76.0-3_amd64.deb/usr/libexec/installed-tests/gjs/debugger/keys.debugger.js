// SPDX-License-Identifier: MIT OR LGPL-2.0-or-later
// SPDX-FileCopyrightText: 2018 Philip Chimento <philip.chimento@gmail.com>
const a = {
    foo: 1,
    bar: null,
    tres: undefined,
    [Symbol('s')]: 'string',
};
debugger;
void a;
