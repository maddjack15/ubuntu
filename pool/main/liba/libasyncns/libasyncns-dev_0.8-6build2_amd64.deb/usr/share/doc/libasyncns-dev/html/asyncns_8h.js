var asyncns_8h =
[
    [ "asyncns_query_t", "asyncns_8h.html#a718cf03acf935a4bdd3cb6cae72279c4", null ],
    [ "asyncns_t", "asyncns_8h.html#a15172969b0b1aeb6cc9ed195448ffe32", null ],
    [ "asyncns_cancel", "asyncns_8h.html#ad9a4c60f1686d340a0ee19027dad6db5", null ],
    [ "asyncns_fd", "asyncns_8h.html#ab22d15f6152b25a5b008082e20596a50", null ],
    [ "asyncns_free", "asyncns_8h.html#a0f5a8f2eede2d5da603a9155c2cd62f4", null ],
    [ "asyncns_freeaddrinfo", "asyncns_8h.html#a47793cbda3d0a4678ff17a152e1ba6ef", null ],
    [ "asyncns_freeanswer", "asyncns_8h.html#a4350da779a9519f100c7887e6649300b", null ],
    [ "asyncns_getaddrinfo", "asyncns_8h.html#a456fcdadc233ceacd282f3b4bc518134", null ],
    [ "asyncns_getaddrinfo_done", "asyncns_8h.html#ab0580ccd4a25ae4688552b51ec08a37a", null ],
    [ "asyncns_getnameinfo", "asyncns_8h.html#a67de1e92655951b7c8644a7a88dcbfb3", null ],
    [ "asyncns_getnameinfo_done", "asyncns_8h.html#a82ec7ebcdfc57517209d1c58e5dd2c23", null ],
    [ "asyncns_getnext", "asyncns_8h.html#a660a0c420f2e478680bfe201fd2a25e4", null ],
    [ "asyncns_getnqueries", "asyncns_8h.html#aef3a72c4b53cea901a0bc966f893707d", null ],
    [ "asyncns_getuserdata", "asyncns_8h.html#af8fa30af58b548f8b0e78c4836fd43c1", null ],
    [ "asyncns_isdone", "asyncns_8h.html#a17c48086dd7dde5ccb63907ea038f0af", null ],
    [ "asyncns_new", "asyncns_8h.html#aba2e450834e523b96e8ce0b121189130", null ],
    [ "asyncns_res_done", "asyncns_8h.html#afc6dc9898292fa5f0c0c86a0131c4f02", null ],
    [ "asyncns_res_query", "asyncns_8h.html#a178e82b47722b74fcc2fa319ff4a6101", null ],
    [ "asyncns_res_search", "asyncns_8h.html#ada9431770c7b2c51db459cc5c2278368", null ],
    [ "asyncns_setuserdata", "asyncns_8h.html#ac008723501f4d029df564a049231549f", null ],
    [ "asyncns_wait", "asyncns_8h.html#a326685a1a341cc9a5f8977d93688fe86", null ]
];