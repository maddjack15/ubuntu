#ifndef ISL_MAYBE_ID_H
#define ISL_MAYBE_ID_H

#define ISL_TYPE	isl_id
#include <isl/maybe_templ.h>
#undef ISL_TYPE

#endif
