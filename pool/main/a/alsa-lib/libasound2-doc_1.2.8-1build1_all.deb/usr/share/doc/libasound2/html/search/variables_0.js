var searchData=
[
  ['abstract_0',['abstract',['../structsnd__mixer__selem__regopt.html#a62d43bde34692931ead4ad14b5ad9821',1,'snd_mixer_selem_regopt']]],
  ['access_1',['access',['../structsnd__pcm__ioplug.html#ac49bda6dd5d2e530d50478be89365ddc',1,'snd_pcm_ioplug::access()'],['../group__topology.html#ga0a3e7fa10db19ea81524fe6a55f92e94',1,'snd_tplg_ctl_template::access()']]],
  ['addr_2',['addr',['../structsnd__pcm__channel__area__t.html#a83acdf3245dcb74dffe74cce53d65876',1,'snd_pcm_channel_area_t::addr()'],['../structsnd__seq__event__t.html#a3a2df2fd3def9f0443bd4759b3cf4077',1,'snd_seq_event_t::addr()']]],
  ['appl_5fptr_3',['appl_ptr',['../structsnd__pcm__ioplug.html#a66cf297ebbce9453b4bbd961f081c730',1,'snd_pcm_ioplug']]]
];
