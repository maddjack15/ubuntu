var searchData=
[
  ['global_20defines_20and_20functions_0',['Global defines and functions',['../group___global.html',1,'']]]
];
