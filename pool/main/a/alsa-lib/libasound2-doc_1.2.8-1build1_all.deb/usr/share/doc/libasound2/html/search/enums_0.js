var searchData=
[
  ['_5fsnd_5fpcm_5ftype_0',['_snd_pcm_type',['../group___p_c_m.html#ga060d5b81f2fc8efcc35ff3e1de6e9fa4',1,'pcm.h']]]
];
