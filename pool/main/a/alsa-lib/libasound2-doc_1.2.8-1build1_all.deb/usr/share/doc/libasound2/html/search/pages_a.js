var searchData=
[
  ['timer_20interface_0',['Timer interface',['../timer.html',1,'index']]]
];
