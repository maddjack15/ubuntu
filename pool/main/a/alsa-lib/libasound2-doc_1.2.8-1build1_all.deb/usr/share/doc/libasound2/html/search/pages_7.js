var searchData=
[
  ['pcm_20_28digital_20audio_29_20interface_0',['PCM (digital audio) interface',['../pcm.html',1,'index']]],
  ['pcm_20_28digital_20audio_29_20plugins_1',['PCM (digital audio) plugins',['../pcm_plugins.html',1,'index']]],
  ['pcm_20external_20plugin_20sdk_2',['PCM External Plugin SDK',['../pcm_external_plugins.html',1,'index']]],
  ['primitive_20control_20plugins_3',['Primitive control plugins',['../control_plugins.html',1,'index']]]
];
