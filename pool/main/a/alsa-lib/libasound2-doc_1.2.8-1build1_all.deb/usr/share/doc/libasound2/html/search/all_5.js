var searchData=
[
  ['elem_0',['elem',['../group__topology.html#ga1600ae422e1746d831b41489df6a6197',1,'snd_tplg_graph_template']]],
  ['elem_5fcount_1',['elem_count',['../structsnd__ctl__ext__callback.html#ab43cecb31b9bd2fb2d87ebdcff67980a',1,'snd_ctl_ext_callback']]],
  ['elem_5flist_2',['elem_list',['../structsnd__ctl__ext__callback.html#a47d137dffe0f0ad99313785bc6abf6d1',1,'snd_ctl_ext_callback']]],
  ['enable_3',['enable',['../structsnd__pcm__scope__ops__t.html#aa744384266d37b6a5da08ef64806057d',1,'snd_pcm_scope_ops_t']]],
  ['enum_5fctl_4',['enum_ctl',['../group__topology.html#gab176a05b65dce92dc7228a6c5c53c96c',1,'snd_tplg_obj_template_t::enum_ctl()'],['../group__topology.html#ga693faf471d19a49e4cddb85cc64c9962',1,'snd_tplg_obj_template_t::@10::enum_ctl()']]],
  ['error_20handling_5',['Error handling',['../group___error.html',1,'']]],
  ['error_2ec_6',['error.c',['../error_8c.html',1,'']]],
  ['error_2eh_7',['error.h',['../error_8h.html',1,'']]],
  ['event_8',['event',['../structsnd__seq__result__t.html#ad1f43479445e2d272a60bec247eb24c0',1,'snd_seq_result_t::event()'],['../structsnd__timer__tread__t.html#afd48df7380e3b1b57b84feaae62c7fc7',1,'snd_timer_tread_t::event()']]],
  ['event_5fflags_9',['event_flags',['../group__topology.html#ga6ddd7e49bae0beeba4f0dea82cd0c0ea',1,'snd_tplg_widget_template']]],
  ['event_5ftype_10',['event_type',['../group__topology.html#ga8a2202f02af34a89c2168ed73bf9168b',1,'snd_tplg_widget_template']]],
  ['ext_11',['ext',['../structsnd__seq__event__t.html#a8074bfd05bf73ae00227f7820dbdad95',1,'snd_seq_event_t']]],
  ['ext_5fops_12',['ext_ops',['../group__topology.html#ga57c109fd38fe1bc72b5338aec60f8245',1,'snd_tplg_bytes_template']]],
  ['external_20control_20plugin_20sdk_13',['External Control Plugin SDK',['../group___ctl_plugin___s_d_k.html',1,'']]],
  ['external_20filter_20plugin_20sdk_14',['External Filter plugin SDK',['../group___p_c_m___ext_plug.html',1,'']]],
  ['external_20i_2fo_20plugin_20sdk_15',['External I/O plugin SDK',['../group___p_c_m___i_o_plug.html',1,'']]],
  ['external_20pcm_20plugin_20sdk_16',['External PCM plugin SDK',['../group___plugin___s_d_k.html',1,'']]]
];
