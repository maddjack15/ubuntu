var searchData=
[
  ['tplg_5falloc_0',['tplg_alloc',['../structtplg__alloc.html',1,'']]],
  ['tuple_5ftype_1',['tuple_type',['../structtuple__type.html',1,'']]]
];
