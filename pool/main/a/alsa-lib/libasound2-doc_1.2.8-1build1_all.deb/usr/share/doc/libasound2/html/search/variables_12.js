var searchData=
[
  ['unused_0',['unused',['../structsnd__seq__ev__ctrl__t.html#a00d5c02a2da001b1d1101d7e310e7c6b',1,'snd_seq_ev_ctrl_t::unused()'],['../structsnd__seq__ev__queue__control__t.html#a60640082c691368f21db12c11ef62aea',1,'snd_seq_ev_queue_control_t::unused()']]],
  ['update_1',['update',['../structsnd__pcm__scope__ops__t.html#a7773ae25296a75fd7fbc58b8fb1974c8',1,'snd_pcm_scope_ops_t']]]
];
