var searchData=
[
  ['optional_20functions_0',['Optional Functions',['../group___a_p_r___util___opt.html',1,'']]],
  ['optional_20hook_20functions_1',['Optional Hook Functions',['../group___a_p_r___util___o_p_t___h_o_o_k.html',1,'']]]
];
