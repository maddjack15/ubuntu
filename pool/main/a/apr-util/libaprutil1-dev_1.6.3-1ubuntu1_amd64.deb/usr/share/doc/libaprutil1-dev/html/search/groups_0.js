var searchData=
[
  ['apr_20utility_20functions_0',['APR Utility Functions',['../group___a_p_r___util.html',1,'']]],
  ['apr_5futil_20error_20values_1',['APR_Util Error Values',['../group___a_p_r___util___error.html',1,'']]]
];
