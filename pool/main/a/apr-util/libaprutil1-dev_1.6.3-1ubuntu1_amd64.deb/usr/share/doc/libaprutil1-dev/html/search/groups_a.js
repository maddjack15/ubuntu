var searchData=
[
  ['redis_20client_20routines_0',['Redis Client Routines',['../group___a_p_r___util___r_c.html',1,'']]],
  ['relocatable_20memory_20management_20routines_1',['Relocatable Memory Management Routines',['../group___a_p_r___util___r_m_m.html',1,'']]],
  ['resource_20list_20routines_2',['Resource List Routines',['../group___a_p_r___util___r_l.html',1,'']]]
];
