#!/bin/sh

/usr/bin/canberra-gtk-play --id="desktop-logout" --description="GNOME Logout"
