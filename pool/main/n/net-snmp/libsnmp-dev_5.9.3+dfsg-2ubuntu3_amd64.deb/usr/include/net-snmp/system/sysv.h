#include <net-snmp/system/generic.h>
#define SYSV 1
