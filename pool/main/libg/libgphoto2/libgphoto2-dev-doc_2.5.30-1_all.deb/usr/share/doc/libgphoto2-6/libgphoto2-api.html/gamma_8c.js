var gamma_8c =
[
    [ "gp_gamma_correct_single", "gamma_8c.html#ac08e35e3aa2292ca6a534264e4b88f97", null ],
    [ "gp_gamma_fill_table", "gamma_8c.html#a6df9d71211778ad700618ffadb83d268", null ]
];