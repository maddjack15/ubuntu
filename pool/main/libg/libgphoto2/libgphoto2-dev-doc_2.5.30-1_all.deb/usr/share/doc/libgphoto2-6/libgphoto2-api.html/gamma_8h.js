var gamma_8h =
[
    [ "gp_gamma_correct_single", "gamma_8h.html#a74f51555b4b41aed7e6b5d575d845e11", null ],
    [ "gp_gamma_fill_table", "gamma_8h.html#a6df9d71211778ad700618ffadb83d268", null ]
];