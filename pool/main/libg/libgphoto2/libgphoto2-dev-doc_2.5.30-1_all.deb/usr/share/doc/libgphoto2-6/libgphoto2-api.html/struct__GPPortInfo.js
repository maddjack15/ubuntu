var struct__GPPortInfo =
[
    [ "library_filename", "struct__GPPortInfo.html#a010cb46938eac00939c73c5e9e5bf57a", null ],
    [ "name", "struct__GPPortInfo.html#ae6fcdc2940c219e28c3a6fb3069f6fe7", null ],
    [ "path", "struct__GPPortInfo.html#a425ac028d0f0566b476a5f110817c3d2", null ],
    [ "type", "struct__GPPortInfo.html#a718fabcbf0232b07ccb4e9b248b3ba03", null ]
];