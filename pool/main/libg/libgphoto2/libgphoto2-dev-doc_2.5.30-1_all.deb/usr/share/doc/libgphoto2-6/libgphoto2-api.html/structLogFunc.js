var structLogFunc =
[
    [ "data", "structLogFunc.html#a9924d784a044385a061cf38ba69acfa1", null ],
    [ "func", "structLogFunc.html#adfa343a5175adcb7a670caf959615b86", null ],
    [ "id", "structLogFunc.html#a8cd5c8a503a285c7598a241cc3ec789e", null ],
    [ "level", "structLogFunc.html#a9dc0273791c4d020e92867460e6fb605", null ]
];