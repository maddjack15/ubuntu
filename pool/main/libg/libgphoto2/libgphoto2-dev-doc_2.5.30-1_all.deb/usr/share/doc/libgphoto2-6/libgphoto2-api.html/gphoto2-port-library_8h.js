var gphoto2_port_library_8h =
[
    [ "_GPPortOperations", "struct__GPPortOperations.html", null ],
    [ "GPPortOperations", "gphoto2-port-library_8h.html#aeffba72bae44b374327d28db689d00a9", null ]
];