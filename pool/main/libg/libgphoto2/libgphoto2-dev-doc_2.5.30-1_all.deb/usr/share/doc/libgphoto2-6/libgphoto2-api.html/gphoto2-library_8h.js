var gphoto2_library_8h =
[
    [ "CameraLibraryAbilitiesFunc", "gphoto2-library_8h.html#a501c0954cd16694fbb9bca030d055266", null ],
    [ "CameraLibraryIdFunc", "gphoto2-library_8h.html#a0f44182b1776dbc85135144a81204f33", null ],
    [ "CameraLibraryInitFunc", "gphoto2-library_8h.html#ae4d3426268c7b31f0f26c0127615223f", null ],
    [ "camera_abilities", "gphoto2-library_8h.html#a14e65a4ed26c2c6e19c54fce9325d1a4", null ],
    [ "camera_id", "gphoto2-library_8h.html#a6b9e41589d48154298976ee65aa9f9d6", null ],
    [ "camera_init", "gphoto2-library_8h.html#af8be80f9a636a9dff8c497cf3cfe0871", null ]
];