var bayer_8c =
[
    [ "gp_bayer_decode", "bayer_8c.html#aed7e2fecaf82319d58da714a4c00932c", null ],
    [ "gp_bayer_expand", "bayer_8c.html#aea1cec99470e5722fff043ecf5167acd", null ],
    [ "gp_bayer_interpolate", "bayer_8c.html#a38afd801f9ae2b9ebcf1924e90b9a28e", null ]
];