var gphoto2_setting_8c =
[
    [ "Setting", "structSetting.html", null ],
    [ "gp_setting_get", "gphoto2-setting_8c.html#a4b50249c04f6a48156bad839827e67b7", null ],
    [ "gp_setting_set", "gphoto2-setting_8c.html#a6100f1cf5f3e90c2491807b6db1796af", null ]
];