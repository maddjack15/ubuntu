var struct__GPPortSettingsUsbScsi =
[
    [ "path", "struct__GPPortSettingsUsbScsi.html#a49c917469a4e9318d728aa15ef6ff9d3", null ]
];