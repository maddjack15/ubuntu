var bayer_8h =
[
    [ "gp_ahd_decode", "bayer_8h.html#a0a10c31feb99742199ca9b8479809ee4", null ],
    [ "gp_ahd_interpolate", "bayer_8h.html#ad3e98332c40eea761faae753444cfcad", null ],
    [ "gp_bayer_decode", "bayer_8h.html#aed7e2fecaf82319d58da714a4c00932c", null ],
    [ "gp_bayer_expand", "bayer_8h.html#aea1cec99470e5722fff043ecf5167acd", null ],
    [ "gp_bayer_interpolate", "bayer_8h.html#a38afd801f9ae2b9ebcf1924e90b9a28e", null ]
];