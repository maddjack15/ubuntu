var struct__GPPortSettingsUsbDiskDirect =
[
    [ "path", "struct__GPPortSettingsUsbDiskDirect.html#ab3d0e0be52031f4465cdee5451796704", null ]
];