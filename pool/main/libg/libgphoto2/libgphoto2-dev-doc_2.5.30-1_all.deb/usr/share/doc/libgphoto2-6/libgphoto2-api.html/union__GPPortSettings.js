var union__GPPortSettings =
[
    [ "serial", "union__GPPortSettings.html#ac5d97643d4d2c83edd17731949966b49", null ],
    [ "usb", "union__GPPortSettings.html#a0aefcc2253c254cac9ea3fb15f2a059b", null ],
    [ "usbdiskdirect", "union__GPPortSettings.html#a9fa1454110af3b6425425de105284c8e", null ],
    [ "usbscsi", "union__GPPortSettings.html#a5e89705555ef3dd1abc7baca312cd253", null ]
];