var struct__CameraFileInfoPreview =
[
    [ "fields", "struct__CameraFileInfoPreview.html#a872f4d1625b0008c625138f33ef3e4cb", null ],
    [ "height", "struct__CameraFileInfoPreview.html#a2cc5f80f66aa90d7c276df9ecd530490", null ],
    [ "size", "struct__CameraFileInfoPreview.html#a9a3b70779dc8cea4d520b9349bee6ba4", null ],
    [ "status", "struct__CameraFileInfoPreview.html#a08eb4d953d2c9f4f7e8ce54223bb8ea9", null ],
    [ "type", "struct__CameraFileInfoPreview.html#a42e378c8d0668052b39c0cca22382dd7", null ],
    [ "width", "struct__CameraFileInfoPreview.html#a12d6115703a502a24cd5b193b75d666a", null ]
];