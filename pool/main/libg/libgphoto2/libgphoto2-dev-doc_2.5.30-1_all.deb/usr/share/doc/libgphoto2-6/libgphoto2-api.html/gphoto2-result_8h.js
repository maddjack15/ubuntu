var gphoto2_result_8h =
[
    [ "GP_ERROR_CAMERA_BUSY", "gphoto2-result_8h.html#a20664ca5181522c2cd0eb70b2d5ecb3c", null ],
    [ "GP_ERROR_CAMERA_ERROR", "gphoto2-result_8h.html#adcbc9d96b811ff4bbcaa56a15c3776bb", null ],
    [ "GP_ERROR_CANCEL", "gphoto2-result_8h.html#a30c02e9e4b9503c1e8be3c24989d71b6", null ],
    [ "GP_ERROR_CORRUPTED_DATA", "gphoto2-result_8h.html#ade2d19223246e133a72869939d103a98", null ],
    [ "GP_ERROR_DIRECTORY_EXISTS", "gphoto2-result_8h.html#a824a44c818defda66b58058cff4fe098", null ],
    [ "GP_ERROR_DIRECTORY_NOT_FOUND", "gphoto2-result_8h.html#a81534050bc881fb2eaa8254645ff928a", null ],
    [ "GP_ERROR_FILE_EXISTS", "gphoto2-result_8h.html#a40abbb8dc46edef840b30ad3d41a764f", null ],
    [ "GP_ERROR_FILE_NOT_FOUND", "gphoto2-result_8h.html#a47c112d78da01466def81f9e6b1b2536", null ],
    [ "GP_ERROR_MODEL_NOT_FOUND", "gphoto2-result_8h.html#aa2ccbde81e188dc5f718a5f219118ff3", null ],
    [ "GP_ERROR_NO_SPACE", "gphoto2-result_8h.html#a3dda38f53245506209b359697e3e6bad", null ],
    [ "GP_ERROR_OS_FAILURE", "gphoto2-result_8h.html#a75bb50bcb30cd384920a29fbab0aa61b", null ],
    [ "GP_ERROR_PATH_NOT_ABSOLUTE", "gphoto2-result_8h.html#a2b1c3f5f9d2a7a30e92200f7d55ece80", null ],
    [ "gp_result_as_string", "gphoto2-result_8h.html#ac0756fbd093a7848d75b44344fc40053", null ]
];