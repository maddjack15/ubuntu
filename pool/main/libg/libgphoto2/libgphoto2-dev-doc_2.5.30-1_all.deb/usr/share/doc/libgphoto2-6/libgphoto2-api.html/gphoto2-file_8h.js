var gphoto2_file_8h =
[
    [ "_CameraFileHandler", "struct__CameraFileHandler.html", null ],
    [ "CameraFileAccessType", "gphoto2-file_8h.html#ae4c27a5589e08db1a4bc37b825dec842", [
      [ "GP_FILE_ACCESSTYPE_MEMORY", "gphoto2-file_8h.html#ae4c27a5589e08db1a4bc37b825dec842add357028781a405fed99210f321aa19f", null ],
      [ "GP_FILE_ACCESSTYPE_FD", "gphoto2-file_8h.html#ae4c27a5589e08db1a4bc37b825dec842a885208212a9c765895d48a3dddd54470", null ],
      [ "GP_FILE_ACCESSTYPE_HANDLER", "gphoto2-file_8h.html#ae4c27a5589e08db1a4bc37b825dec842af8d7ad7cfc3baaa5135ca835d4e388c7", null ]
    ] ],
    [ "CameraFileType", "gphoto2-file_8h.html#ab9f339bdf374343272c62d2352753d69", [
      [ "GP_FILE_TYPE_PREVIEW", "gphoto2-file_8h.html#ab9f339bdf374343272c62d2352753d69a533cccf7871c3ddfe182425f0b1a06f9", null ],
      [ "GP_FILE_TYPE_NORMAL", "gphoto2-file_8h.html#ab9f339bdf374343272c62d2352753d69aa8534dad4e3b2024cf8eae58fdbe940f", null ],
      [ "GP_FILE_TYPE_RAW", "gphoto2-file_8h.html#ab9f339bdf374343272c62d2352753d69af9deb2f536e56d6546239f785c29f7c8", null ],
      [ "GP_FILE_TYPE_AUDIO", "gphoto2-file_8h.html#ab9f339bdf374343272c62d2352753d69a8e7f28766023ea910ca6e34f4745f915", null ],
      [ "GP_FILE_TYPE_EXIF", "gphoto2-file_8h.html#ab9f339bdf374343272c62d2352753d69adfc3456d99351d80f6d514cd130f8c62", null ],
      [ "GP_FILE_TYPE_METADATA", "gphoto2-file_8h.html#ab9f339bdf374343272c62d2352753d69a5f9e4fc5c19d2f49b1539d61ebc7d824", null ]
    ] ],
    [ "gp_file_adjust_name_for_mime_type", "gphoto2-file_8h.html#a73b0c6e00946621ea45b3a04d92165a2", null ],
    [ "gp_file_append", "gphoto2-file_8h.html#afe87b1e2f9df858f3737bb0d603a0d6e", null ],
    [ "gp_file_clean", "gphoto2-file_8h.html#a6fca699d500239610e276fef064adc2f", null ],
    [ "gp_file_copy", "gphoto2-file_8h.html#a9aa6499669a0ab66844030440655a0ff", null ],
    [ "gp_file_detect_mime_type", "gphoto2-file_8h.html#ac31856165a1b0fb6e64b06a5a47b8cc7", null ],
    [ "gp_file_free", "gphoto2-file_8h.html#ac0058da71651fd4068306be65fa680cc", null ],
    [ "gp_file_get_data_and_size", "gphoto2-file_8h.html#a14a65df63ea8de52cca12e2596000e92", null ],
    [ "gp_file_get_mime_type", "gphoto2-file_8h.html#a4415b2867b1a8d6c032018db99fd3fee", null ],
    [ "gp_file_get_mtime", "gphoto2-file_8h.html#aba965b1a676ea68194cb4052b3dea00d", null ],
    [ "gp_file_get_name", "gphoto2-file_8h.html#a58b455d8aa49d2a01429ce3475c9f873", null ],
    [ "gp_file_get_name_by_type", "gphoto2-file_8h.html#ab9c078f6915a3186c90ff81cc52da898", null ],
    [ "gp_file_new", "gphoto2-file_8h.html#af0d1d638d7a58ae9591be458eeb13c72", null ],
    [ "gp_file_new_from_fd", "gphoto2-file_8h.html#a0376d5d1c7af0edde33cdbe7f3d2eb1e", null ],
    [ "gp_file_new_from_handler", "gphoto2-file_8h.html#a874cdc7c50e2946e4fe96794a61766af", null ],
    [ "gp_file_open", "gphoto2-file_8h.html#a77b7d521ef9e2bf405e97717dd836d43", null ],
    [ "gp_file_ref", "gphoto2-file_8h.html#aca2b7ed7d1b91fcdb0578ee71142a101", null ],
    [ "gp_file_save", "gphoto2-file_8h.html#a56e413d5ea3abc6e512b92c5861b9594", null ],
    [ "gp_file_set_data_and_size", "gphoto2-file_8h.html#aa74b5ef3f426b9a97ef4cde4e04225d5", null ],
    [ "gp_file_set_mime_type", "gphoto2-file_8h.html#ab0c9c2ff2ef54f2ead016ed5a82f895f", null ],
    [ "gp_file_set_mtime", "gphoto2-file_8h.html#ae2f0802d187957c104a3bb6925edc95a", null ],
    [ "gp_file_set_name", "gphoto2-file_8h.html#ab2fc202bdab8503ab5dca38357dff494", null ],
    [ "gp_file_slurp", "gphoto2-file_8h.html#a6b14aa2ac7af75fc48125d515fb63038", null ],
    [ "gp_file_unref", "gphoto2-file_8h.html#aa330c62c510ed9c05a678a319ff807a6", null ]
];