var gphoto2_port_info_8h =
[
    [ "_GPPortInfo", "struct__GPPortInfo.html", "struct__GPPortInfo" ]
];