var struct__GPPort =
[
    [ "pc", "struct__GPPort.html#a1faa59ebce39788197df90820ad8b0f5", null ],
    [ "pl", "struct__GPPort.html#a3936923a7b803e3e9f5f07b12538dbf3", null ],
    [ "settings", "struct__GPPort.html#a55f035abd153028c9e178f14175b9497", null ],
    [ "settings_pending", "struct__GPPort.html#a1df8c387e3e769254f0c53830a6ac486", null ],
    [ "timeout", "struct__GPPort.html#a22703106e8f0116367f20695bb10a6e0", null ],
    [ "type", "struct__GPPort.html#ac7dd2545df0b8380aa2016c35dbfb7de", null ]
];