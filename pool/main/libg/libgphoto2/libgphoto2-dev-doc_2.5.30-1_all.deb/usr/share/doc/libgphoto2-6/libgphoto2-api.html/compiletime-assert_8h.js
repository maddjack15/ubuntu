var compiletime_assert_8h =
[
    [ "BARE_COMPILETIME_ASSERT", "compiletime-assert_8h.html#ae2664eb70bc4a470ded3c32f5f555978", null ],
    [ "COMPILETIME_ASSERT", "compiletime-assert_8h.html#a7033865ab91d3e8a7044a6f237729c0a", null ]
];