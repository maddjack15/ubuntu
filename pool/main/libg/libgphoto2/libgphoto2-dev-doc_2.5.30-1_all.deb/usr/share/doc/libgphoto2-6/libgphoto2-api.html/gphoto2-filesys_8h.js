var gphoto2_filesys_8h =
[
    [ "_CameraFileInfoFile", "struct__CameraFileInfoFile.html", "struct__CameraFileInfoFile" ],
    [ "_CameraFileInfoPreview", "struct__CameraFileInfoPreview.html", "struct__CameraFileInfoPreview" ],
    [ "_CameraFileInfoAudio", "struct__CameraFileInfoAudio.html", "struct__CameraFileInfoAudio" ],
    [ "_CameraFileInfo", "struct__CameraFileInfo.html", null ],
    [ "_CameraStorageInformation", "struct__CameraStorageInformation.html", "struct__CameraStorageInformation" ],
    [ "_CameraFilesystemFuncs", "struct__CameraFilesystemFuncs.html", null ],
    [ "CameraFileInfo", "gphoto2-filesys_8h.html#a5521a0eba8d4f7706dfd506109ef5ec4", null ],
    [ "CameraFileInfoAudio", "gphoto2-filesys_8h.html#a5b6ad64bc00efa2cf7e67c6564f6b323", null ],
    [ "CameraFileInfoFile", "gphoto2-filesys_8h.html#a8055e77bcd3700e80365e104963ac5d3", null ],
    [ "CameraFileInfoPreview", "gphoto2-filesys_8h.html#a5db5df72a4392ada3038917a307ae77c", null ],
    [ "CameraFilesystem", "gphoto2-filesys_8h.html#a1a9fdae1cac2fbf67abb9ad360ec2bc4", null ],
    [ "CameraStorageInformation", "gphoto2-filesys_8h.html#a93ff2d464d58b21701632683becd0b15", null ],
    [ "CameraFileInfoFields", "gphoto2-filesys_8h.html#a6ee15bfa0ff8bf74872e13a87e1a4907", [
      [ "GP_FILE_INFO_NONE", "gphoto2-filesys_8h.html#a6ee15bfa0ff8bf74872e13a87e1a4907a70c192de7c121febde90af7e117c0eed", null ],
      [ "GP_FILE_INFO_TYPE", "gphoto2-filesys_8h.html#a6ee15bfa0ff8bf74872e13a87e1a4907a259e66be4884ad572ca319e0c510d52f", null ],
      [ "GP_FILE_INFO_SIZE", "gphoto2-filesys_8h.html#a6ee15bfa0ff8bf74872e13a87e1a4907a7f0cc4ba19d9f92f2e8e12de6580f47b", null ],
      [ "GP_FILE_INFO_WIDTH", "gphoto2-filesys_8h.html#a6ee15bfa0ff8bf74872e13a87e1a4907a02d7794e26a9b4333cec58a82ac31d61", null ],
      [ "GP_FILE_INFO_HEIGHT", "gphoto2-filesys_8h.html#a6ee15bfa0ff8bf74872e13a87e1a4907a0a0190e06a2d872347d099378cb20b6a", null ],
      [ "GP_FILE_INFO_PERMISSIONS", "gphoto2-filesys_8h.html#a6ee15bfa0ff8bf74872e13a87e1a4907a9ed3048a35c2f6a59d6e89e52f24b1a5", null ],
      [ "GP_FILE_INFO_STATUS", "gphoto2-filesys_8h.html#a6ee15bfa0ff8bf74872e13a87e1a4907a6603c2d07d8d87bfc5378f99f0869665", null ],
      [ "GP_FILE_INFO_MTIME", "gphoto2-filesys_8h.html#a6ee15bfa0ff8bf74872e13a87e1a4907a9277302e076066219975e49bbc574600", null ],
      [ "GP_FILE_INFO_ALL", "gphoto2-filesys_8h.html#a6ee15bfa0ff8bf74872e13a87e1a4907a7c19dc619e18629df027df1f8aaa1035", null ]
    ] ],
    [ "CameraFilePermissions", "gphoto2-filesys_8h.html#a2e0fe092c4fd0e08f28018503c985def", [
      [ "GP_FILE_PERM_NONE", "gphoto2-filesys_8h.html#a2e0fe092c4fd0e08f28018503c985defae8c0a7b576f9e7a136db4a8098dc2e2d", null ],
      [ "GP_FILE_PERM_READ", "gphoto2-filesys_8h.html#a2e0fe092c4fd0e08f28018503c985defa19ee3c09396fb571102f8f8603b2ba07", null ],
      [ "GP_FILE_PERM_DELETE", "gphoto2-filesys_8h.html#a2e0fe092c4fd0e08f28018503c985defa17ee5aed70a5a7ea58b148b95f9f6b4b", null ],
      [ "GP_FILE_PERM_ALL", "gphoto2-filesys_8h.html#a2e0fe092c4fd0e08f28018503c985defa03a88392838e9aed558b03c1753f7c3c", null ]
    ] ],
    [ "CameraFileStatus", "gphoto2-filesys_8h.html#a91d62408f248d2017e4c7648ad1bb7f4", [
      [ "GP_FILE_STATUS_NOT_DOWNLOADED", "gphoto2-filesys_8h.html#a91d62408f248d2017e4c7648ad1bb7f4a202afeb359e8e0d70223c0e91d21ae38", null ],
      [ "GP_FILE_STATUS_DOWNLOADED", "gphoto2-filesys_8h.html#a91d62408f248d2017e4c7648ad1bb7f4a56c0581a5ee75fb38c1e9048afd41924", null ]
    ] ],
    [ "CameraStorageAccessType", "gphoto2-filesys_8h.html#aefa6778c8c4ffa5010d5308b8e3b1ab2", [
      [ "GP_STORAGEINFO_AC_READWRITE", "gphoto2-filesys_8h.html#aefa6778c8c4ffa5010d5308b8e3b1ab2a69537cf990705349e4fd4ea0c340307c", null ],
      [ "GP_STORAGEINFO_AC_READONLY", "gphoto2-filesys_8h.html#aefa6778c8c4ffa5010d5308b8e3b1ab2a3a247a3380670d37c66144344c36baa4", null ],
      [ "GP_STORAGEINFO_AC_READONLY_WITH_DELETE", "gphoto2-filesys_8h.html#aefa6778c8c4ffa5010d5308b8e3b1ab2af426d95fa6dd5459a18a470a2cb2358d", null ]
    ] ],
    [ "CameraStorageFilesystemType", "gphoto2-filesys_8h.html#aec0f51755c7c91b0896126f344d4116c", [
      [ "GP_STORAGEINFO_FST_UNDEFINED", "gphoto2-filesys_8h.html#aec0f51755c7c91b0896126f344d4116cafe69ebf8c62b4cf3f7e5ebc41cf0fd5e", null ],
      [ "GP_STORAGEINFO_FST_GENERICFLAT", "gphoto2-filesys_8h.html#aec0f51755c7c91b0896126f344d4116ca0de1b0a69f91388b1df7dda2ed474a6f", null ],
      [ "GP_STORAGEINFO_FST_GENERICHIERARCHICAL", "gphoto2-filesys_8h.html#aec0f51755c7c91b0896126f344d4116ca38e6bb9584f838c854ec46629d28d6c9", null ],
      [ "GP_STORAGEINFO_FST_DCF", "gphoto2-filesys_8h.html#aec0f51755c7c91b0896126f344d4116cac137487ec95bc28d9617a8c7d956372e", null ]
    ] ],
    [ "CameraStorageInfoFields", "gphoto2-filesys_8h.html#aea5262d6ac9a1821a55e25cdcbe026c4", [
      [ "GP_STORAGEINFO_BASE", "gphoto2-filesys_8h.html#aea5262d6ac9a1821a55e25cdcbe026c4ada86006b5dbcce13bcb04f2cc26f147e", null ],
      [ "GP_STORAGEINFO_LABEL", "gphoto2-filesys_8h.html#aea5262d6ac9a1821a55e25cdcbe026c4aa022e27fb1ebb0ca85c9bf9f27aaa2ed", null ],
      [ "GP_STORAGEINFO_DESCRIPTION", "gphoto2-filesys_8h.html#aea5262d6ac9a1821a55e25cdcbe026c4ac6edf5e003f594b1ed4ce70f1151a4a4", null ],
      [ "GP_STORAGEINFO_ACCESS", "gphoto2-filesys_8h.html#aea5262d6ac9a1821a55e25cdcbe026c4a658387c29bcabb6493fd78e4c31e6a3e", null ],
      [ "GP_STORAGEINFO_STORAGETYPE", "gphoto2-filesys_8h.html#aea5262d6ac9a1821a55e25cdcbe026c4aecc73ff61e6a2d5d320b0a89c20f278f", null ],
      [ "GP_STORAGEINFO_FILESYSTEMTYPE", "gphoto2-filesys_8h.html#aea5262d6ac9a1821a55e25cdcbe026c4a547c7f1bb9bb57642f603af5eab5674d", null ],
      [ "GP_STORAGEINFO_MAXCAPACITY", "gphoto2-filesys_8h.html#aea5262d6ac9a1821a55e25cdcbe026c4a5a95a037a450fd7a4301b4a38fe86c96", null ],
      [ "GP_STORAGEINFO_FREESPACEKBYTES", "gphoto2-filesys_8h.html#aea5262d6ac9a1821a55e25cdcbe026c4a270d683b66c2546f3a8a99d4367ec8ff", null ],
      [ "GP_STORAGEINFO_FREESPACEIMAGES", "gphoto2-filesys_8h.html#aea5262d6ac9a1821a55e25cdcbe026c4aa332258d1cb37717005f74806ce82660", null ]
    ] ],
    [ "CameraStorageType", "gphoto2-filesys_8h.html#ac292d4b7907e404add85e0dcbb9ed231", [
      [ "GP_STORAGEINFO_ST_UNKNOWN", "gphoto2-filesys_8h.html#ac292d4b7907e404add85e0dcbb9ed231a61f39b9997144d327e93c4e5b64595c2", null ],
      [ "GP_STORAGEINFO_ST_FIXED_ROM", "gphoto2-filesys_8h.html#ac292d4b7907e404add85e0dcbb9ed231a09f99d4b613aff38c40ebdbb85ccc6eb", null ],
      [ "GP_STORAGEINFO_ST_REMOVABLE_ROM", "gphoto2-filesys_8h.html#ac292d4b7907e404add85e0dcbb9ed231a11d081b722614ac59f7ed792c3a74748", null ],
      [ "GP_STORAGEINFO_ST_FIXED_RAM", "gphoto2-filesys_8h.html#ac292d4b7907e404add85e0dcbb9ed231a84e10c1aa7a878a296f5174725466a9b", null ],
      [ "GP_STORAGEINFO_ST_REMOVABLE_RAM", "gphoto2-filesys_8h.html#ac292d4b7907e404add85e0dcbb9ed231ac1b06b5aef1ab800ca8f1d98b4400376", null ]
    ] ],
    [ "gp_filesystem_count", "gphoto2-filesys_8h.html#a7fdf2e5f1c7fda4b0f7f58f45a33c71c", null ],
    [ "gp_filesystem_delete_all", "gphoto2-filesys_8h.html#a6b6fc659abe86a1724fe6600d112931f", null ],
    [ "gp_filesystem_delete_file", "gphoto2-filesys_8h.html#a4d1424f4d45018dc892a2da792822f0c", null ],
    [ "gp_filesystem_delete_file_noop", "gphoto2-filesys_8h.html#aa6cd62861b01c157efcdf25dd2753576", null ],
    [ "gp_filesystem_dump", "gphoto2-filesys_8h.html#a0e785e85f4a199ee87dfd7604ad8d45a", null ],
    [ "gp_filesystem_free", "gphoto2-filesys_8h.html#a08fa6e05d77adce0b6be853c226dedaa", null ],
    [ "gp_filesystem_get_file", "gphoto2-filesys_8h.html#a7bbfa59b2587d36fa5be529c788f9585", null ],
    [ "gp_filesystem_get_folder", "gphoto2-filesys_8h.html#a083ea3fd7f794f6de09c1c51ba142572", null ],
    [ "gp_filesystem_get_info", "gphoto2-filesys_8h.html#ac58c62bed856f6b143aaa776d74b5705", null ],
    [ "gp_filesystem_get_storageinfo", "gphoto2-filesys_8h.html#a8890288b06b5ffdf16aa328050e2bae6", null ],
    [ "gp_filesystem_list_files", "gphoto2-filesys_8h.html#a97c3a1cb9996eb8319d232023209bf19", null ],
    [ "gp_filesystem_list_folders", "gphoto2-filesys_8h.html#ae6106ac2f70f59b50525a8de870ec25b", null ],
    [ "gp_filesystem_make_dir", "gphoto2-filesys_8h.html#a42bad7d5fc4433d353f1d336f575c340", null ],
    [ "gp_filesystem_name", "gphoto2-filesys_8h.html#ab22748e14f4e4d0492c4ddeeec557e70", null ],
    [ "gp_filesystem_new", "gphoto2-filesys_8h.html#a3c12781d176e73fb9e8795d29e64f56e", null ],
    [ "gp_filesystem_number", "gphoto2-filesys_8h.html#af9cb8b2135e3eaf71ee864fed2d56212", null ],
    [ "gp_filesystem_put_file", "gphoto2-filesys_8h.html#ae1e4bab15af84be9873bbd14b383da25", null ],
    [ "gp_filesystem_read_file", "gphoto2-filesys_8h.html#aed55d9d55663c0cc58f002a176ad2aa4", null ],
    [ "gp_filesystem_remove_dir", "gphoto2-filesys_8h.html#af55d08507d98adf2b02d1efe5f78623d", null ],
    [ "gp_filesystem_reset", "gphoto2-filesys_8h.html#a57f7b7038489eadd5a78787d6cfe8d66", null ],
    [ "gp_filesystem_set_file_noop", "gphoto2-filesys_8h.html#a7ee1e023cac99c0e96d28954bd626b19", null ],
    [ "gp_filesystem_set_funcs", "gphoto2-filesys_8h.html#a6f6d981b8ab1273e8048df66670782ab", null ],
    [ "gp_filesystem_set_info", "gphoto2-filesys_8h.html#a3ffbe7ac58a11c688edd98369741f828", null ],
    [ "gp_filesystem_set_info_dirty", "gphoto2-filesys_8h.html#a660a952a1107a18da00614d1a48fc2e5", null ],
    [ "gp_filesystem_set_info_noop", "gphoto2-filesys_8h.html#a4e4ea8548673cc56c465ee447dd916f3", null ]
];