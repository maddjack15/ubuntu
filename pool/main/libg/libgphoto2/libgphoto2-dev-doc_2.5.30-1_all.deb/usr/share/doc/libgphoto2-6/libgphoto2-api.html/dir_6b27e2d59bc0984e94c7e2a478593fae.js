var dir_6b27e2d59bc0984e94c7e2a478593fae =
[
    [ "compiletime-assert.h", "compiletime-assert_8h.html", "compiletime-assert_8h" ],
    [ "gphoto2-port-info-list.c", "gphoto2-port-info-list_8c.html", "gphoto2-port-info-list_8c" ],
    [ "gphoto2-port-info.h", "gphoto2-port-info_8h.html", "gphoto2-port-info_8h" ],
    [ "gphoto2-port-log.c", "gphoto2-port-log_8c.html", "gphoto2-port-log_8c" ],
    [ "gphoto2-port-portability.c", "gphoto2-port-portability_8c.html", "gphoto2-port-portability_8c" ],
    [ "gphoto2-port-result.c", "gphoto2-port-result_8c.html", "gphoto2-port-result_8c" ],
    [ "gphoto2-port-version.c", "gphoto2-port-version_8c.html", null ],
    [ "gphoto2-port.c", "gphoto2-port_8c.html", "gphoto2-port_8c" ],
    [ "i18n.h", "libgphoto2__port_2libgphoto2__port_2i18n_8h.html", null ]
];