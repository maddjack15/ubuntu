var struct__CameraStorageInformation =
[
    [ "access", "struct__CameraStorageInformation.html#a8bd76351601c330356c8656cc0e580f1", null ],
    [ "basedir", "struct__CameraStorageInformation.html#a2a263c93947db1b47bca9e7298840eca", null ],
    [ "capacitykbytes", "struct__CameraStorageInformation.html#a468551e2079facf00b9acc97798fa30f", null ],
    [ "description", "struct__CameraStorageInformation.html#a1d192e8ebbd2367b90d1e0bcb69f02e4", null ],
    [ "fields", "struct__CameraStorageInformation.html#a10890d64e63a7e95624ad3258ea94199", null ],
    [ "freeimages", "struct__CameraStorageInformation.html#a54d368755af52b0b4991e5cd8e706271", null ],
    [ "freekbytes", "struct__CameraStorageInformation.html#a0076093883131f7a90b6961c2455e573", null ],
    [ "fstype", "struct__CameraStorageInformation.html#a8b96dab747312da81a5b0702882b002b", null ],
    [ "label", "struct__CameraStorageInformation.html#aedb405bbdd1d882040d14bbf983818e9", null ],
    [ "type", "struct__CameraStorageInformation.html#a7e1cdd21daa0d4d710a66d35a2cee25a", null ]
];