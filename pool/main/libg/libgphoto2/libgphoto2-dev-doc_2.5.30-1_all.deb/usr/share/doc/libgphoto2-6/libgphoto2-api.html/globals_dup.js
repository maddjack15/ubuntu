var globals_dup =
[
    [ "_", "globals.html", null ],
    [ "b", "globals_b.html", null ],
    [ "c", "globals_c.html", null ],
    [ "d", "globals_d.html", null ],
    [ "f", "globals_f.html", null ],
    [ "g", "globals_g.html", null ],
    [ "h", "globals_h.html", null ],
    [ "p", "globals_p.html", null ],
    [ "s", "globals_s.html", null ]
];