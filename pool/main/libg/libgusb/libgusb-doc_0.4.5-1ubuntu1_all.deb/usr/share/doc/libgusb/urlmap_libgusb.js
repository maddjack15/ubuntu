baseURLs = [
	[ 'Gio', 'https://people.gnome.org/~ebassi/docs/_build/Gio/' ],
	[ 'GObject', 'https://people.gnome.org/~ebassi/docs/_build/GObject/' ],
]
