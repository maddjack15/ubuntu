#!/bin/sh

setupcon
