#include <stdio.h>
#include <stdlib.h>

int main(void)
{
    double *a;

    a =  malloc (10*sizeof *a);
    
    a[10]=-999;
    
    free(a);
    a = NULL;
    
    return EXIT_SUCCESS;
}
