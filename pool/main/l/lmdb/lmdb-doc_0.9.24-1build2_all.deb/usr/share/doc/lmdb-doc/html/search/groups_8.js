var searchData=
[
  ['transaction_20db_20flags_0',['Transaction DB Flags',['../group__mt__dbflag.html',1,'']]],
  ['transaction_20flags_1',['Transaction Flags',['../group__mdb__txn.html',1,'']]]
];
