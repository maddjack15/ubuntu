var searchData=
[
  ['getting_20started_0',['Getting Started',['../starting.html',1,'']]]
];
