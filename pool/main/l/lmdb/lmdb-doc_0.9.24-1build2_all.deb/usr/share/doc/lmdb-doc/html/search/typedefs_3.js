var searchData=
[
  ['txnid_5ft_0',['txnid_t',['../group__internal.html#gabbaef7c9c710f8652a62c32d748c040e',1,'mdb.c']]]
];
