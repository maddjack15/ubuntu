var searchData=
[
  ['next_5floose_5fpage_0',['NEXT_LOOSE_PAGE',['../group__internal.html#ga9bebe2cf570ff3959aefcad1fadfd6c2',1,'mdb.c']]],
  ['node_20flags_1',['Node Flags',['../group__mdb__node.html',1,'']]],
  ['node_5fadd_5fflags_2',['NODE_ADD_FLAGS',['../group__mdb__node.html#ga8dbbb28473b39ed9d19dc4e7b5b4dd52',1,'mdb.c']]],
  ['nodedata_3',['NODEDATA',['../group__internal.html#gaaa3f3816301d68365052b69a0c1464e1',1,'mdb.c']]],
  ['nodedsz_4',['NODEDSZ',['../group__internal.html#ga8f307b7c4ebae2194b30328bc87c4070',1,'mdb.c']]],
  ['nodekey_5',['NODEKEY',['../group__internal.html#ga0c2d3ecf490b76fd5ef32aa4082edefe',1,'mdb.c']]],
  ['nodeksz_6',['NODEKSZ',['../group__internal.html#gaa680cb94fd0c91a8818205fcef2d1b53',1,'mdb.c']]],
  ['nodepgno_7',['NODEPGNO',['../group__internal.html#gabc71d778f3391485aee252505fb06e90',1,'mdb.c']]],
  ['nodeptr_8',['NODEPTR',['../group__internal.html#gadd8222b06a62d77398a5d719e973a66d',1,'mdb.c']]],
  ['nodesize_9',['NODESIZE',['../group__internal.html#ga7d24748fedf732c90d840cbf0714d8d8',1,'mdb.c']]],
  ['num_5fmetas_10',['NUM_METAS',['../group__internal.html#gae066f6a2b21f2003b622dc654bc58327',1,'mdb.c']]],
  ['numkeys_11',['NUMKEYS',['../group__internal.html#ga7c4518ae24926f5f96d70a97c14fcad8',1,'mdb.c']]]
];
