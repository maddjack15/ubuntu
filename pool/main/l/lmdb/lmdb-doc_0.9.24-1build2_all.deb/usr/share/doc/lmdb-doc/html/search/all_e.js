var searchData=
[
  ['todo_20list_0',['Todo List',['../todo.html',1,'']]],
  ['transaction_20db_20flags_1',['Transaction DB Flags',['../group__mt__dbflag.html',1,'']]],
  ['transaction_20flags_2',['Transaction Flags',['../group__mdb__txn.html',1,'']]],
  ['txn_5fdbi_5fchanged_3',['TXN_DBI_CHANGED',['../group__internal.html#ga1d4c1bd5bcb0a3cf8d281fa4868d5b8d',1,'mdb.c']]],
  ['txn_5fdbi_5fexist_4',['TXN_DBI_EXIST',['../group__internal.html#ga595c1d82481e8c361da5b32f1dbe1ffd',1,'mdb.c']]],
  ['txnid_5ft_5',['txnid_t',['../group__internal.html#gabbaef7c9c710f8652a62c32d748c040e',1,'mdb.c']]]
];
