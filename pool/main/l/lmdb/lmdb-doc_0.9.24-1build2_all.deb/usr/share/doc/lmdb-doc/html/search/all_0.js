var searchData=
[
  ['c_5fdel_0',['C_DEL',['../group__mdb__cursor.html#ga186b8075211f880eab30e33434e511a9',1,'mdb.c']]],
  ['c_5feof_1',['C_EOF',['../group__mdb__cursor.html#gaf3433775e39a8f78e6bdcac026b9354d',1,'mdb.c']]],
  ['c_5finitialized_2',['C_INITIALIZED',['../group__mdb__cursor.html#ga491771b32c4fdf08d7b66ffb20bbbb32',1,'mdb.c']]],
  ['c_5fsub_3',['C_SUB',['../group__mdb__cursor.html#ga31bd2871aca0e24b95e6d50b916f7b5b',1,'mdb.c']]],
  ['c_5funtrack_4',['C_UNTRACK',['../group__mdb__cursor.html#ga79af151f605df221750d7cecbbf498eb',1,'mdb.c']]],
  ['cacheline_5',['CACHELINE',['../group__readers.html#gaa62717a1fae2c57f94f2a9b8ae08ec49',1,'mdb.c']]],
  ['changeable_6',['CHANGEABLE',['../group__internal.html#ga73e66d763b8c4837cce5369052628bbe',1,'mdb.c']]],
  ['compatibility_20macros_7',['Compatibility Macros',['../group__compat.html',1,'']]],
  ['copy_20flags_8',['Copy Flags',['../group__mdb__copy.html',1,'']]],
  ['copy_5fpgno_9',['COPY_PGNO',['../group__internal.html#gaa2e6eaaa9f8fcfd2078846caf2249895',1,'mdb.c']]],
  ['core_5fdbs_10',['CORE_DBS',['../group__internal.html#ga9c5573d169b885743bc9208c23c7e82b',1,'mdb.c']]],
  ['cursor_20flags_11',['Cursor Flags',['../group__mdb__cursor.html',1,'']]],
  ['cursor_5fstack_12',['CURSOR_STACK',['../group__internal.html#gaef453f149efb721c2eb311a6ede48dc8',1,'mdb.c']]]
];
