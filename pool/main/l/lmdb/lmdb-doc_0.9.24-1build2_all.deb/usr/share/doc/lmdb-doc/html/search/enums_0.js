var searchData=
[
  ['mdb_5fcursor_5fop_0',['MDB_cursor_op',['../group__mdb__copy.html#ga1206b2af8b95e7f6b0ef6b28708c9127',1,'lmdb.h']]],
  ['mdb_5ffopen_5ftype_1',['mdb_fopen_type',['../group__internal.html#ga395ba0adc08527de3caed146e65c9726',1,'mdb.c']]]
];
