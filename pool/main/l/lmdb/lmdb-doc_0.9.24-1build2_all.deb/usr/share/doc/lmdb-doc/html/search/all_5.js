var searchData=
[
  ['handle_0',['HANDLE',['../group__compat.html#gab521aa5010fb1afb801a899a55569e03',1,'mdb.c']]]
];
