var searchData=
[
  ['reader_0',['reader',['../group__internal.html#a0ca555e0c624a93f7106cfea434e9557',1,'MDB_txn']]],
  ['reader_20lock_20table_1',['Reader Lock Table',['../group__readers.html',1,'']]],
  ['return_20codes_2',['Return Codes',['../group__errors.html',1,'']]]
];
