var searchData=
[
  ['valid_5fflags_0',['VALID_FLAGS',['../group__internal.html#ga999f0ca5c5a7c2e736a21f3aab93cebc',1,'mdb.c']]],
  ['version_20macros_1',['Version Macros',['../group__Version.html',1,'']]]
];
