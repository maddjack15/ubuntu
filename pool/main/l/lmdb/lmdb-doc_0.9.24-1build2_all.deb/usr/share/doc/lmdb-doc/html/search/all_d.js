var searchData=
[
  ['setdsz_0',['SETDSZ',['../group__internal.html#ga737db862c118cd893ac8d6a87f6175fe',1,'mdb.c']]],
  ['setpgno_1',['SETPGNO',['../group__internal.html#ga220e51ef0d2da4d4ff58e94065eaa095',1,'mdb.c']]],
  ['sizeleft_2',['SIZELEFT',['../group__internal.html#gadec51e874501c53388b820f27a937654',1,'mdb.c']]]
];
