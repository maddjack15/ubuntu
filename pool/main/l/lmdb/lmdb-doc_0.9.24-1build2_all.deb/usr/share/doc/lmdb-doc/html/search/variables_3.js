var searchData=
[
  ['reader_0',['reader',['../group__internal.html#a0ca555e0c624a93f7106cfea434e9557',1,'MDB_txn']]]
];
