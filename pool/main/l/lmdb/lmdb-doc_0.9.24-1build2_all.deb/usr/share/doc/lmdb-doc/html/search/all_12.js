var searchData=
[
  ['xcursor_5finited_0',['XCURSOR_INITED',['../group__internal.html#ga3984b0c84521b4cc360e3f280dde75e7',1,'mdb.c']]],
  ['xcursor_5frefresh_1',['XCURSOR_REFRESH',['../group__internal.html#ga3876e09a141d0992dc588b8cec4b71eb',1,'mdb.c']]]
];
