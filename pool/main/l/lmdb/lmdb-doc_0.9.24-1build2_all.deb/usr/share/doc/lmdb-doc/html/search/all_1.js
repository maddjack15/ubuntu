var searchData=
[
  ['database_20flags_0',['Database Flags',['../group__mdb__dbi__open.html',1,'']]],
  ['db_5fdirty_1',['DB_DIRTY',['../group__mt__dbflag.html#ga787c81e5c1fc66acb6499e91cf0277a5',1,'mdb.c']]],
  ['db_5fdupdata_2',['DB_DUPDATA',['../group__mt__dbflag.html#ga118c1be1527e7f4b7438e990ec7bec0d',1,'mdb.c']]],
  ['db_5fnew_3',['DB_NEW',['../group__mt__dbflag.html#gaa34ab4f3219e045f382b2cb9dd4b1fe1',1,'mdb.c']]],
  ['db_5fstale_4',['DB_STALE',['../group__mt__dbflag.html#ga5f4ab5cd9a3f9a427ad7eec85ea7d6bb',1,'mdb.c']]],
  ['db_5fusrvalid_5',['DB_USRVALID',['../group__mt__dbflag.html#gadb138759ab6050eb44273a92882c61eb',1,'mdb.c']]],
  ['db_5fvalid_6',['DB_VALID',['../group__mt__dbflag.html#gac774963973e18f60ae646b7295219a8d',1,'mdb.c']]],
  ['ddbi_7',['DDBI',['../group__debug.html#ga3d9bdd340721e2f3acd537dd250aa016',1,'mdb.c']]],
  ['debug_20macros_8',['Debug Macros',['../group__debug.html',1,'']]],
  ['default_5fmapsize_9',['DEFAULT_MAPSIZE',['../group__internal.html#ga506f893519db205966f7988c03c920f5',1,'mdb.c']]],
  ['default_5freaders_10',['DEFAULT_READERS',['../group__readers.html#gadff1f7b4d4626610a8d616e0c6dbbea4',1,'mdb.c']]],
  ['dirty_5flist_11',['dirty_list',['../group__internal.html#a0a89cc7b39f5aec84f629a2b43bb64d5',1,'MDB_txn']]],
  ['dputs_12',['DPUTS',['../group__debug.html#ga326823abd056b96347c5925b8b2a055b',1,'mdb.c']]]
];
