var searchData=
[
  ['compatibility_20macros_0',['Compatibility Macros',['../group__compat.html',1,'']]],
  ['copy_20flags_1',['Copy Flags',['../group__mdb__copy.html',1,'']]],
  ['cursor_20flags_2',['Cursor Flags',['../group__mdb__cursor.html',1,'']]]
];
