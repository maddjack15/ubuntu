var searchData=
[
  ['database_20flags_0',['Database Flags',['../group__mdb__dbi__open.html',1,'']]],
  ['debug_20macros_1',['Debug Macros',['../group__debug.html',1,'']]]
];
