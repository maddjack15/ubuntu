var searchData=
[
  ['get_5fpagesize_0',['GET_PAGESIZE',['../group__compat.html#ga948570910e2e84a556977f585cbfa2bf',1,'mdb.c']]],
  ['getting_20started_1',['Getting Started',['../starting.html',1,'']]]
];
