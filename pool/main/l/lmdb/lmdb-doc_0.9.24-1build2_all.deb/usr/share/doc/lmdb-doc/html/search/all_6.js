var searchData=
[
  ['id_20list_20management_0',['ID List Management',['../group__idls.html',1,'']]],
  ['indx_5ft_1',['indx_t',['../group__internal.html#ga730e17f748208d77496ebd895c8375dc',1,'mdb.c']]],
  ['indxsize_2',['INDXSIZE',['../group__internal.html#gae17cd0c2dbe9e5f346e6fefbe64a94b8',1,'mdb.c']]],
  ['invalid_5fhandle_5fvalue_3',['INVALID_HANDLE_VALUE',['../group__compat.html#ga5fdc7facea201bfce4ad308105f88d0c',1,'mdb.c']]],
  ['is_5fbranch_4',['IS_BRANCH',['../group__internal.html#gac3a145e1e46a73a21f95e1076717cf38',1,'mdb.c']]],
  ['is_5fleaf_5',['IS_LEAF',['../group__internal.html#gac047007d585883bfc8cbc82e9a7f041a',1,'mdb.c']]],
  ['is_5fleaf2_6',['IS_LEAF2',['../group__internal.html#gaac1756ae5ed27a7103224a0219b42c75',1,'mdb.c']]],
  ['is_5foverflow_7',['IS_OVERFLOW',['../group__internal.html#ga4907ee7e1f797f841e8708715c16175c',1,'mdb.c']]],
  ['is_5fsubp_8',['IS_SUBP',['../group__internal.html#ga4ca60a25dcbc659b2a01d5ef6de91119',1,'mdb.c']]]
];
