GPU Performance Tracing
=======================

TODO: Add general tips for performance measurement.

.. toctree::
   :maxdepth: 1

   u_trace
   perfetto
