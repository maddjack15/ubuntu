void whoopsie_identifier_generate (char** res, GError** error);
void whoopsie_identifier_get_imei (char** res, GError** error);
void whoopsie_identifier_get_mac_address (char** res, GError** error);
void whoopsie_identifier_get_system_uuid (char** res, GError** error);
void whoopsie_identifier_get_android_serialno (char** res, GError** error);
void whoopsie_identifier_sha512 (char* source, char* res, GError** error);
void whoopsie_hex_to_char (char* buf, const char *str, int len);
#define HASHLEN 128

/* for testing: */
void whoopsie_identifier_set_ofono_name (char* name) __attribute__ ((__warning__ ("Only for testing")));
void whoopsie_identifier_set_cache_file (char* filename) __attribute__ ((__warning__ ("Only for testing")));
void whoopsie_identifier_fail_next_get_mac (gint how) __attribute__ ((__warning__ ("Only for testing")));
void whoopsie_identifier_fail_next_get_uuid () __attribute__ ((__warning__ ("Only for testing")));
void whoopsie_identifier_fail_next_get_serial () __attribute__ ((__warning__ ("Only for testing")));
#define WHOOPSIE_FAIL_GENERIC 1
#define WHOOPSIE_FAIL_NO_IFACES 2
#define WHOOPSIE_FAILED_BY_REQUEST 42

/* The file path for publishing whoopsie_identifier */
#define WHOOPSIE_ID_PATH "/var/lib/whoopsie/whoopsie-id"
