var group__pw__factory =
[
    [ "factory.h", "factory_8h.html", null ],
    [ "pw_factory_info", "structpw__factory__info.html", [
      [ "id", "structpw__factory__info.html#aa930c209d3ae55baeaebff7edc38a02b", null ],
      [ "type", "structpw__factory__info.html#a76b3448ac2229cdcbe42c28f824dcf0b", null ],
      [ "version", "structpw__factory__info.html#a0b9fcbe083fe5205459705da31d45f97", null ],
      [ "change_mask", "structpw__factory__info.html#adc3bf8dcfbfb3dbf0ed7f3638a659f46", null ]
    ] ],
    [ "pw_factory_events", "structpw__factory__events.html", [
      [ "version", "structpw__factory__events.html#a92c9ad52c5b502a07bb45e29504dad2f", null ],
      [ "info", "structpw__factory__events.html#ad58b5fc377977b0ce5eef6877549a9b8", null ]
    ] ],
    [ "pw_factory_methods", "structpw__factory__methods.html", [
      [ "version", "structpw__factory__methods.html#aa3d553e1352e95ecc6870f28cb98a5fe", null ],
      [ "add_listener", "structpw__factory__methods.html#af8cbd6088a874710de9c066169a75d6a", null ]
    ] ],
    [ "pw_factory", "structpw__factory.html", null ],
    [ "PW_TYPE_INTERFACE_Factory", "group__pw__factory.html#ga7fef05e5e22b45e8e6052d81cba5c5f9", null ],
    [ "PW_VERSION_FACTORY", "group__pw__factory.html#ga2b5efdcc62cf19b9b0a73dd2efe56f28", null ],
    [ "PW_FACTORY_CHANGE_MASK_PROPS", "group__pw__factory.html#ga51e0173b2c4ab941d1d50bf91d57349a", null ],
    [ "PW_FACTORY_CHANGE_MASK_ALL", "group__pw__factory.html#ga20a0f841514dfbccd4f1a364d78965f6", null ],
    [ "PW_FACTORY_EVENT_INFO", "group__pw__factory.html#ga25957ad664132e8215873d1527a79ebf", null ],
    [ "PW_FACTORY_EVENT_NUM", "group__pw__factory.html#ga565ebd175faec4b843ffe6829808ec63", null ],
    [ "PW_VERSION_FACTORY_EVENTS", "group__pw__factory.html#ga71d1b88f6cff611d5bbe569f8cc8502f", null ],
    [ "PW_FACTORY_METHOD_ADD_LISTENER", "group__pw__factory.html#ga16ea600d61f6c2a7babe1f874f4b88d4", null ],
    [ "PW_FACTORY_METHOD_NUM", "group__pw__factory.html#gaf8409d3aaaaebb821234326de899ff30", null ],
    [ "PW_VERSION_FACTORY_METHODS", "group__pw__factory.html#ga1de4e3330980837b8b75253ed1f775dc", null ],
    [ "pw_factory_method", "group__pw__factory.html#ga1c07909569c65641cad412ee0ec66b91", null ],
    [ "pw_factory_add_listener", "group__pw__factory.html#ga1b0eb091b706f16d33bf996bdcb61150", null ],
    [ "pw_factory_info_update", "group__pw__factory.html#ga387c43690478f34c23952eb04ae7685f", null ],
    [ "pw_factory_info_merge", "group__pw__factory.html#ga1f34fa1270bef86ac879b376f00b6ab1", null ],
    [ "pw_factory_info_free", "group__pw__factory.html#ga92137402a680368de028afb6d0ea3c7b", null ]
];