var group__pw__pipewire =
[
    [ "pipewire.h", "pipewire_8h.html", null ],
    [ "pw_init", "group__pw__pipewire.html#ga06c879b2d800579f4724109054368d99", null ],
    [ "pw_deinit", "group__pw__pipewire.html#gafa6045cd7391b467af4575c6752d6c4e", null ],
    [ "pw_debug_is_category_enabled", "group__pw__pipewire.html#gacc287aaae982260a49eeac97f27a8227", null ],
    [ "pw_get_application_name", "group__pw__pipewire.html#ga61cbf71ec9b7c562cedb8a5a9ab04ceb", null ],
    [ "pw_get_prgname", "group__pw__pipewire.html#ga1bffd3e2e02f201486d7d9f17950e5eb", null ],
    [ "pw_get_user_name", "group__pw__pipewire.html#gae7a5b43b7a86b9e79e9b3c3c549bdf65", null ],
    [ "pw_get_host_name", "group__pw__pipewire.html#ga592c823ee1ec9f4be102f2dbe70f5aa5", null ],
    [ "pw_get_client_name", "group__pw__pipewire.html#gafb27fefe2f3d0620f973c2c76ae3ba8b", null ],
    [ "pw_in_valgrind", "group__pw__pipewire.html#ga245d94286ccbb5c23cec4448cc7070f0", null ],
    [ "pw_check_option", "group__pw__pipewire.html#ga52ada5751f37cb0e32ae79d20c1bf508", null ],
    [ "pw_direction_reverse", "group__pw__pipewire.html#ga4efeba27bea1dc8d9188b8e49b3bd1b0", null ],
    [ "pw_set_domain", "group__pw__pipewire.html#ga9b3cd1e03874212edf11b91bd1db9cda", null ],
    [ "pw_get_domain", "group__pw__pipewire.html#ga4e623813e79083f48f7654973d440fb0", null ],
    [ "pw_get_support", "group__pw__pipewire.html#ga0a42d8f153fc58df733f74e5bf9af251", null ],
    [ "pw_load_spa_handle", "group__pw__pipewire.html#gaab274e4e74769e7fab76ff7965740427", null ],
    [ "pw_unload_spa_handle", "group__pw__pipewire.html#gaf3d7686492ea5032eb135cddf21d3da2", null ]
];