var group__pw__control =
[
    [ "src/pipewire/control.h", "src_2pipewire_2control_8h.html", null ],
    [ "pw_control_events", "structpw__control__events.html", [
      [ "version", "structpw__control__events.html#a4d456606837f25ad3e55471ae23c6bdc", null ],
      [ "destroy", "structpw__control__events.html#ad23091c8931adf9aa85564b31e2d9ca8", null ],
      [ "free", "structpw__control__events.html#a4e2a4c85f61336fb837a43c931b7c5fa", null ],
      [ "linked", "structpw__control__events.html#adbd47ebc650888ca6235b763fa3f6ef2", null ],
      [ "unlinked", "structpw__control__events.html#a2cda9616fd4aa65d7cc2f8dc6efe69dc", null ]
    ] ],
    [ "pw_control", "structpw__control.html", null ],
    [ "PW_VERSION_CONTROL_EVENTS", "group__pw__control.html#ga0be21158c54fbe4d6d249ca26759c118", null ],
    [ "pw_control_get_port", "group__pw__control.html#gaa415a0aa3dcaf77a1d075edfb888a52c", null ],
    [ "pw_control_add_listener", "group__pw__control.html#ga95fdd2d1b4b991f93e3ace1c8cf3b24c", null ]
];