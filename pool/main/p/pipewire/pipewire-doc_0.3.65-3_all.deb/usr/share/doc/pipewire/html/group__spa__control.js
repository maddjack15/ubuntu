var group__spa__control =
[
    [ "spa/include/spa/control/control.h", "spa_2include_2spa_2control_2control_8h.html", null ],
    [ "control/type-info.h", "control_2type-info_8h.html", null ],
    [ "SPA_TYPE_INFO_Control", "group__spa__control.html#ga9b962fde9cc692dbe986897dde0c0d12", null ],
    [ "SPA_TYPE_INFO_CONTROL_BASE", "group__spa__control.html#gadf0c4f48af09389e78636d98a64372d3", null ],
    [ "spa_control_type", "group__spa__control.html#ga9780c9a5192589544170788a97f20b82", [
      [ "SPA_CONTROL_Invalid", "group__spa__control.html#gga9780c9a5192589544170788a97f20b82a3a88d096c3a127009cf375f6b3550f0d", null ],
      [ "SPA_CONTROL_Properties", "group__spa__control.html#gga9780c9a5192589544170788a97f20b82a47faf7403339d87fdc4e96a929d6f146", null ],
      [ "SPA_CONTROL_Midi", "group__spa__control.html#gga9780c9a5192589544170788a97f20b82ae446ab493d4562323aa95b59cf56c2ad", null ],
      [ "SPA_CONTROL_OSC", "group__spa__control.html#gga9780c9a5192589544170788a97f20b82a5fa56c93ca27aa6e55406b4691ad70b1", null ],
      [ "_SPA_CONTROL_LAST", "group__spa__control.html#gga9780c9a5192589544170788a97f20b82a6d60da01306a62b9def5922f36870b6d", null ]
    ] ],
    [ "spa_type_control", "group__spa__control.html#ga96f78bb42bed09dc96696e2413215bc6", null ]
];