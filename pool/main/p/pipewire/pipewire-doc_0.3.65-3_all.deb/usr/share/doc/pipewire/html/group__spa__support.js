var group__spa__support =
[
    [ "CPU", "group__spa__cpu.html", "group__spa__cpu" ],
    [ "DBus", "group__spa__dbus.html", "group__spa__dbus" ],
    [ "I18N", "group__spa__i18n.html", "group__spa__i18n" ],
    [ "Log", "group__spa__log.html", "group__spa__log" ],
    [ "Loop", "group__spa__loop.html", "group__spa__loop" ],
    [ "Plugin Handle", "group__spa__handle.html", "group__spa__handle" ],
    [ "Plugin Loader", "group__spa__plugin__loader.html", "group__spa__plugin__loader" ],
    [ "System", "group__spa__system.html", "group__spa__system" ],
    [ "Thread", "group__spa__thread.html", "group__spa__thread" ]
];