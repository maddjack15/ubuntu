var group__pw__gettext =
[
    [ "src/pipewire/i18n.h", "src_2pipewire_2i18n_8h.html", null ],
    [ "_", "group__pw__gettext.html#ga32a3cf3d9dd914f5aeeca5423c157934", null ],
    [ "N_", "group__pw__gettext.html#ga75278405e7f034d2b1af80bfd94675fe", null ],
    [ "SPA_FORMAT_ARG_FUNC", "group__pw__gettext.html#ga13fa16d21c2d32f812f8cb071b6d8794", null ]
];