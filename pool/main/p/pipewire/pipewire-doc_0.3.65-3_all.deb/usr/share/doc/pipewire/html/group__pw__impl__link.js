var group__pw__impl__link =
[
    [ "impl-link.h", "impl-link_8h.html", null ],
    [ "pw_impl_link_events", "structpw__impl__link__events.html", [
      [ "version", "structpw__impl__link__events.html#a05c9fec1c6580f673d09e33005bca5ee", null ],
      [ "destroy", "structpw__impl__link__events.html#a8e6dceaefdbbe793d1eba749370a3f25", null ],
      [ "free", "structpw__impl__link__events.html#a7cf5965ff2f975aba7ac061938e1fa9c", null ],
      [ "initialized", "structpw__impl__link__events.html#ae136867ff703e789d52dbb2ef427726d", null ],
      [ "info_changed", "structpw__impl__link__events.html#a36d3179004ca94bfe99cfc7c7608321a", null ],
      [ "state_changed", "structpw__impl__link__events.html#a05b20c99f1014e62e0d032b92382f584", null ],
      [ "port_unlinked", "structpw__impl__link__events.html#ad161d67256c9fd29f54cc53dbacb10d5", null ]
    ] ],
    [ "pw_impl_link", "structpw__impl__link.html", null ],
    [ "pw_impl_port", "structpw__impl__port.html", null ],
    [ "PW_VERSION_IMPL_LINK_EVENTS", "group__pw__impl__link.html#ga38b19e4241a7f7d2d78668ee49844498", null ],
    [ "pw_context_create_link", "group__pw__impl__link.html#ga7d7c433db2954a961e4980a37168dc6d", null ],
    [ "pw_impl_link_destroy", "group__pw__impl__link.html#ga3baed016411a9a3d0f7407c3a9144b39", null ],
    [ "pw_impl_link_add_listener", "group__pw__impl__link.html#ga34599919dcc1b77b5953b0d7ace5a33e", null ],
    [ "pw_impl_link_register", "group__pw__impl__link.html#ga065a23032eb7a487d4d310432b86d584", null ],
    [ "pw_impl_link_get_context", "group__pw__impl__link.html#gadb0804873e86008517da37361440f3d7", null ],
    [ "pw_impl_link_get_user_data", "group__pw__impl__link.html#gad8161cd03199abe6e0d76f3067e024f8", null ],
    [ "pw_impl_link_get_info", "group__pw__impl__link.html#ga67ddececedcfc23e682f0b860fcde648", null ],
    [ "pw_impl_link_get_global", "group__pw__impl__link.html#ga8a9522e49aa17d076831c7e18026bc5a", null ],
    [ "pw_impl_link_get_output", "group__pw__impl__link.html#ga1d14d440f9b78ff302371e49fca32a36", null ],
    [ "pw_impl_link_get_input", "group__pw__impl__link.html#gacc36539d4d6dfb2064d0ffa36b13d0ae", null ],
    [ "pw_impl_link_find", "group__pw__impl__link.html#ga9dec6e3bcc59c5d9e7fb70bf36f86dd8", null ]
];