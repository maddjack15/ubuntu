var group__spa__handle =
[
    [ "plugin.h", "plugin_8h.html", null ],
    [ "spa_handle", "structspa__handle.html", [
      [ "version", "structspa__handle.html#aaf5d3406480eab83a92db807bc2154c5", null ],
      [ "get_interface", "structspa__handle.html#a28e6fe4b4f4bdd29f007a1339cbe972a", null ],
      [ "clear", "structspa__handle.html#aaef038ef76a15ddaf5833510535716b4", null ]
    ] ],
    [ "spa_interface_info", "structspa__interface__info.html", [
      [ "type", "structspa__interface__info.html#acdbeeba8f234386bc1a937604c234e40", null ]
    ] ],
    [ "spa_support", "structspa__support.html", [
      [ "type", "structspa__support.html#adbf0320367c082c9e5e0e4d4b2ab07d5", null ],
      [ "data", "structspa__support.html#a65463ddc17cb6271875443f52cb7deab", null ]
    ] ],
    [ "spa_handle_factory", "structspa__handle__factory.html", [
      [ "version", "structspa__handle__factory.html#a528ffc68aa9b406e094c04bba09bbc10", null ],
      [ "info", "structspa__handle__factory.html#a6edd8af903eeb185389da41ee945158f", null ],
      [ "get_size", "structspa__handle__factory.html#aa48d0b857861f618011a9f4a89435484", null ],
      [ "init", "structspa__handle__factory.html#ad9e9ca49d03aed627c1c1ac5db5266d7", null ],
      [ "enum_interface_info", "structspa__handle__factory.html#a00264d237fb8d45b1878d8ea32fbb5b2", null ]
    ] ],
    [ "SPA_VERSION_HANDLE", "group__spa__handle.html#ga3b2dbcdf4e34e7341390b6fb18580050", null ],
    [ "spa_handle_get_interface", "group__spa__handle.html#gab524b05355e460875e4bade86be05f1f", null ],
    [ "spa_handle_clear", "group__spa__handle.html#ga9f21d7f6a4f24433a28d0a1a1a36fc2c", null ],
    [ "SPA_SUPPORT_INIT", "group__spa__handle.html#ga46953719ebad900370c1ac50ac1a9fcd", null ],
    [ "SPA_VERSION_HANDLE_FACTORY", "group__spa__handle.html#gafa9d7675b710d31bc5646638f8f1d8a8", null ],
    [ "spa_handle_factory_get_size", "group__spa__handle.html#gaf86d765fc97b67683398613eaa7e06dc", null ],
    [ "spa_handle_factory_init", "group__spa__handle.html#ga80a85bc1c6b1fc47a4ffe42da9879ef0", null ],
    [ "spa_handle_factory_enum_interface_info", "group__spa__handle.html#gae0b82ce5f9c3144367ec1f53446c242c", null ],
    [ "SPA_HANDLE_FACTORY_ENUM_FUNC_NAME", "group__spa__handle.html#ga15ebd649c6523fbcfc798ac37607950f", null ],
    [ "SPA_KEY_FACTORY_NAME", "group__spa__handle.html#ga18920d5c66cf89e7b7f9786cc7288e2e", null ],
    [ "SPA_KEY_FACTORY_AUTHOR", "group__spa__handle.html#ga7496cf82187d5f26cee9a0bd04dfcdad", null ],
    [ "SPA_KEY_FACTORY_DESCRIPTION", "group__spa__handle.html#gaee6f3174721d9909a7b532e68b9faaff", null ],
    [ "SPA_KEY_FACTORY_USAGE", "group__spa__handle.html#ga002303dd0962faff5b0f15ea48488635", null ],
    [ "SPA_KEY_LIBRARY_NAME", "group__spa__handle.html#ga4e62fbcdd6d7152561184e6366cefe6b", null ],
    [ "spa_handle_factory_enum_func_t", "group__spa__handle.html#ga12bab914d8b3939f802d93439768bfd4", null ],
    [ "spa_support_find", "group__spa__handle.html#ga82f1b02dfb782a24ed624e16392b1e12", null ],
    [ "spa_handle_factory_enum", "group__spa__handle.html#gaec2d5563ec9ea8d6c4155ca6525ae3b7", null ]
];