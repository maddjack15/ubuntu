var group__pw__client =
[
    [ "client.h", "client_8h.html", null ],
    [ "pw_client_info", "structpw__client__info.html", [
      [ "id", "structpw__client__info.html#a8585e5629d10bb4359ede29782fd7c21", null ],
      [ "change_mask", "structpw__client__info.html#a9123521af948ea7b720d1ebb0f39c66b", null ]
    ] ],
    [ "pw_client_events", "structpw__client__events.html", [
      [ "version", "structpw__client__events.html#a0ceb2ae8884ca4a30bae720198410075", null ],
      [ "info", "structpw__client__events.html#a58af5a46ef2875bf85f2683ed522d254", null ],
      [ "permissions", "structpw__client__events.html#af685647fe57d1a9dba2a0d89d32aae39", null ]
    ] ],
    [ "pw_client_methods", "structpw__client__methods.html", [
      [ "version", "structpw__client__methods.html#a898d61fc799b5c09421365854020b357", null ],
      [ "add_listener", "structpw__client__methods.html#ad5cf20929a275ce91d7fdbbb80e70be3", null ],
      [ "error", "structpw__client__methods.html#a298f33a5d81477d06b08f52d233b740a", null ],
      [ "update_properties", "structpw__client__methods.html#a17155250b4b575de0530a8d01447148a", null ],
      [ "get_permissions", "structpw__client__methods.html#a7af9e64e81ebc0b3a7d726ff98e0dd84", null ],
      [ "update_permissions", "structpw__client__methods.html#a2804d8a526c068a486a4e261821c9a07", null ]
    ] ],
    [ "pw_client", "structpw__client.html", null ],
    [ "PW_TYPE_INTERFACE_Client", "group__pw__client.html#ga08028eb8b2bc7e721c22cd0683d0fd59", null ],
    [ "PW_VERSION_CLIENT", "group__pw__client.html#gab23fc368d6d3c8dc6737af396c8ebdc4", null ],
    [ "PW_ID_CLIENT", "group__pw__client.html#ga2effc0dcfd9a3dd90e72dde47f58fa62", null ],
    [ "PW_CLIENT_CHANGE_MASK_PROPS", "group__pw__client.html#gae4b0f81c2ec7e2249624a5f3bbe3db2d", null ],
    [ "PW_CLIENT_CHANGE_MASK_ALL", "group__pw__client.html#ga46fcb2a45cd729fd11659e81c4875339", null ],
    [ "PW_CLIENT_EVENT_INFO", "group__pw__client.html#ga2e599d0e1c57ae7418e7a58604f30290", null ],
    [ "PW_CLIENT_EVENT_PERMISSIONS", "group__pw__client.html#ga64aacff6f50a099bd9f4f292af5053a8", null ],
    [ "PW_CLIENT_EVENT_NUM", "group__pw__client.html#gae9c05c6686aa7db3f69466363e7b8077", null ],
    [ "PW_VERSION_CLIENT_EVENTS", "group__pw__client.html#gab0377cbf13596f969016266bc277b60b", null ],
    [ "PW_CLIENT_METHOD_ADD_LISTENER", "group__pw__client.html#ga1144b60d4d77eb5b5bda140e6dd31e13", null ],
    [ "PW_CLIENT_METHOD_ERROR", "group__pw__client.html#ga33efb76dc1c04741209f7c313b0a6e6e", null ],
    [ "PW_CLIENT_METHOD_UPDATE_PROPERTIES", "group__pw__client.html#gad7327a543c437159816d4256e84e370b", null ],
    [ "PW_CLIENT_METHOD_GET_PERMISSIONS", "group__pw__client.html#gaffa5b807a9674495aa5c14a68d5fd88c", null ],
    [ "PW_CLIENT_METHOD_UPDATE_PERMISSIONS", "group__pw__client.html#ga44649b91990bb998e81a97c45fac4975", null ],
    [ "PW_CLIENT_METHOD_NUM", "group__pw__client.html#ga6ab68453545662580dfb9ef12eb99cc4", null ],
    [ "PW_VERSION_CLIENT_METHODS", "group__pw__client.html#gaca345ef08d2fe2316b793b2721489e7d", null ],
    [ "pw_client_method", "group__pw__client.html#ga2e47a9955d2344ceeca575ddbfea546a", null ],
    [ "pw_client_add_listener", "group__pw__client.html#gaf334e712707cd3d4fb97100f3baedeb0", null ],
    [ "pw_client_error", "group__pw__client.html#gaca741a1eb7d2306a1d06f7236bdcdd53", null ],
    [ "pw_client_update_properties", "group__pw__client.html#ga376200cda9564550fda412c327cab29d", null ],
    [ "pw_client_get_permissions", "group__pw__client.html#gad6b676ec28f1d8598d37c3b73a4f06b9", null ],
    [ "pw_client_update_permissions", "group__pw__client.html#ga9429f541161b89136e87de99499d42d4", null ],
    [ "pw_client_info_update", "group__pw__client.html#ga534848e70aa11c5f41df3c8c9751c2bf", null ],
    [ "pw_client_info_merge", "group__pw__client.html#ga5aba78585d56fbbd77f87b7d841f633a", null ],
    [ "pw_client_info_free", "group__pw__client.html#ga0052817a42d359a4b306d77717e2bec9", null ]
];