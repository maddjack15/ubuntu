var group__pw__global =
[
    [ "global.h", "global_8h.html", null ],
    [ "pw_global_events", "structpw__global__events.html", [
      [ "version", "structpw__global__events.html#a909a601dfd3ce02c04c0e714df6450a1", null ],
      [ "destroy", "structpw__global__events.html#a8ccd4e331a4c1a0401e13ab3c9b04236", null ],
      [ "free", "structpw__global__events.html#a57040ccb9805bda67581693d06c0cea6", null ],
      [ "permissions_changed", "structpw__global__events.html#a914924700d817cb9d4f58c327d5952e8", null ]
    ] ],
    [ "pw_global", "structpw__global.html", null ],
    [ "PW_VERSION_GLOBAL_EVENTS", "group__pw__global.html#gadd2cfdc756b647e5f68c159a38473f40", null ],
    [ "pw_global_bind_func_t", "group__pw__global.html#ga2e57ee773c977a1f07591ff4c34998ab", null ],
    [ "pw_global_new", "group__pw__global.html#ga1c989c1a28c830cea0edab08cd20561c", null ],
    [ "pw_global_register", "group__pw__global.html#gaf901fcdcb9d2059370fdd9d6ad188c3f", null ],
    [ "pw_global_add_listener", "group__pw__global.html#ga48ade1ac8c560225b6d54dedbc48836a", null ],
    [ "pw_global_get_permissions", "group__pw__global.html#ga2d270212a3e0583ec582dcd79c81d6ff", null ],
    [ "pw_global_get_context", "group__pw__global.html#ga1d1659a1635d2c477ae3abea7a993812", null ],
    [ "pw_global_get_type", "group__pw__global.html#ga8d552ee37d074785a447cba33ba8a9af", null ],
    [ "pw_global_is_type", "group__pw__global.html#gaeed9fccaa847e8fb5422555f391d4d50", null ],
    [ "pw_global_get_version", "group__pw__global.html#ga3e5b2dd59d6cf7c614c3ed24b041a8b7", null ],
    [ "pw_global_get_properties", "group__pw__global.html#ga8dfcaca80107a9f45dc6a604c0bce2d6", null ],
    [ "pw_global_update_keys", "group__pw__global.html#gaefc7f1061bce8e8aef0a8dae894087b5", null ],
    [ "pw_global_get_object", "group__pw__global.html#gae35b9eb5ebbdead2e5a79845d5fa2031", null ],
    [ "pw_global_get_id", "group__pw__global.html#ga5a70a0e4be433825f0e5baf7277c0e7e", null ],
    [ "pw_global_get_serial", "group__pw__global.html#ga37767f3d8d027ae10433a0801cab0dda", null ],
    [ "pw_global_add_resource", "group__pw__global.html#gab6796dae933803798be1658f4020315c", null ],
    [ "pw_global_for_each_resource", "group__pw__global.html#ga74a7902607d041b9ebea8ad223af7a2d", null ],
    [ "pw_global_bind", "group__pw__global.html#ga167d705465c32b170a5da6346decbf7e", null ],
    [ "pw_global_update_permissions", "group__pw__global.html#ga7c5ab037320ab252af6eb6eb1b85b0b9", null ],
    [ "pw_global_destroy", "group__pw__global.html#ga64e7b1922846aee0f5c9c6b16606506b", null ]
];