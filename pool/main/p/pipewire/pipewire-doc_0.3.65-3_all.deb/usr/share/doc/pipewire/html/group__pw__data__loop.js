var group__pw__data__loop =
[
    [ "data-loop.h", "data-loop_8h.html", null ],
    [ "pw_data_loop_events", "structpw__data__loop__events.html", [
      [ "version", "structpw__data__loop__events.html#a19c5624deda8fb2d4fd452bf6ba6c3b8", null ],
      [ "destroy", "structpw__data__loop__events.html#a5ee1e79472b7ab5aab28d40df7a1db0b", null ]
    ] ],
    [ "pw_data_loop", "structpw__data__loop.html", null ],
    [ "PW_VERSION_DATA_LOOP_EVENTS", "group__pw__data__loop.html#gaa9cf928c292b70257b5533ca6702fecf", null ],
    [ "pw_data_loop_new", "group__pw__data__loop.html#ga95ff4526c1e3310f05859eaacfd227d9", null ],
    [ "pw_data_loop_add_listener", "group__pw__data__loop.html#ga31fb97e55669c3673f4912ff08fc25f5", null ],
    [ "pw_data_loop_wait", "group__pw__data__loop.html#ga1c1a7caf16eb1d6d6b3927c483bcfcb6", null ],
    [ "pw_data_loop_exit", "group__pw__data__loop.html#gae566b4ae45ffa6127fa159e1289470d0", null ],
    [ "pw_data_loop_get_loop", "group__pw__data__loop.html#ga8f39e0b037a34bdf90d1146dff84c9bb", null ],
    [ "pw_data_loop_destroy", "group__pw__data__loop.html#ga9e8300a978c0a9ecefb54dc6b23f333c", null ],
    [ "pw_data_loop_start", "group__pw__data__loop.html#ga1ca9b85ed7dde1f8f011f2d47dd87dab", null ],
    [ "pw_data_loop_stop", "group__pw__data__loop.html#ga305854e5e85ba6d923be6448871de951", null ],
    [ "pw_data_loop_in_thread", "group__pw__data__loop.html#gabfa6227e4d5ff8870e856769871ae0f7", null ],
    [ "pw_data_loop_get_thread", "group__pw__data__loop.html#ga2a920ff68c8ca96a1764a67d9918b6c4", null ],
    [ "pw_data_loop_invoke", "group__pw__data__loop.html#gad0477df28007005f31c8267c62cccd5e", null ],
    [ "pw_data_loop_set_thread_utils", "group__pw__data__loop.html#ga2ab40cdd269df6297256fe5048bb5b29", null ]
];