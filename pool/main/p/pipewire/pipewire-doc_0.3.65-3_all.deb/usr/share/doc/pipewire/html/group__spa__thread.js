var group__spa__thread =
[
    [ "spa/include/spa/support/thread.h", "spa_2include_2spa_2support_2thread_8h.html", null ],
    [ "spa_thread_utils", "structspa__thread__utils.html", [
      [ "iface", "structspa__thread__utils.html#add4d911915f7c8e76b9c646389facf70", null ]
    ] ],
    [ "spa_thread_utils_methods", "structspa__thread__utils__methods.html", [
      [ "version", "structspa__thread__utils__methods.html#a68878e9b02ee15f3590d4c871a97d74a", null ],
      [ "create", "structspa__thread__utils__methods.html#aa0c4c049d9406510ff457400df373ceb", null ],
      [ "join", "structspa__thread__utils__methods.html#ab1126024161570f88d077ecee01066e8", null ],
      [ "get_rt_range", "structspa__thread__utils__methods.html#aa5a251e895f44dd6f48ee3014f0546e4", null ],
      [ "acquire_rt", "structspa__thread__utils__methods.html#adaa8eb3e63f991d91dbb6246fd4f6c3e", null ],
      [ "drop_rt", "structspa__thread__utils__methods.html#a3324347184f8b1caa930012817982c41", null ]
    ] ],
    [ "spa_thread", "structspa__thread.html", null ],
    [ "SPA_TYPE_INFO_Thread", "group__spa__thread.html#ga36d6661f31950920b85cd0c48fc68a33", null ],
    [ "SPA_TYPE_INTERFACE_ThreadUtils", "group__spa__thread.html#ga6680e7f42845ca460cdaa93abd568e02", null ],
    [ "SPA_VERSION_THREAD_UTILS", "group__spa__thread.html#ga4f716da417d838544df4e82f4670b79c", null ],
    [ "SPA_VERSION_THREAD_UTILS_METHODS", "group__spa__thread.html#ga7454dd6c4ac2967b5c53936dc6ec00b5", null ],
    [ "SPA_KEY_THREAD_NAME", "group__spa__thread.html#gaa3418c60a3ab55c44596d0c37ff0fe1b", null ],
    [ "SPA_KEY_THREAD_STACK_SIZE", "group__spa__thread.html#ga5d2d0635caeef22aaa5a63681255219d", null ],
    [ "spa_thread_utils_create", "group__spa__thread.html#ga7c5acfdece976cd3f7b12dee4ddb3e41", null ],
    [ "spa_thread_utils_join", "group__spa__thread.html#ga8dcf8fcd02dbf3c2c49afe37e40b6a43", null ],
    [ "spa_thread_utils_get_rt_range", "group__spa__thread.html#ga13cf7d6799ad80fe7e3f69874032d529", null ],
    [ "spa_thread_utils_acquire_rt", "group__spa__thread.html#ga087f55566e08c2bb1536574b7556a66f", null ],
    [ "spa_thread_utils_drop_rt", "group__spa__thread.html#gae1224b4702957d8a48f7c17cf350f5a2", null ]
];