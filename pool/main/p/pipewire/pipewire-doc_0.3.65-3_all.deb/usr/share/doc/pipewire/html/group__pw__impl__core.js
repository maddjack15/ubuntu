var group__pw__impl__core =
[
    [ "impl-core.h", "impl-core_8h.html", null ],
    [ "pw_impl_core_events", "structpw__impl__core__events.html", [
      [ "version", "structpw__impl__core__events.html#a53a597c0d67497f0fd3661c6d0518686", null ],
      [ "destroy", "structpw__impl__core__events.html#a3189bc6a80618c55e8320da100edf0c4", null ],
      [ "free", "structpw__impl__core__events.html#a7fa1d92430edc18d7d8fb645b8879cbf", null ],
      [ "initialized", "structpw__impl__core__events.html#a9ac4ac7169ad8ea008945360c63ad1a3", null ]
    ] ],
    [ "pw_impl_core", "structpw__impl__core.html", null ],
    [ "PW_VERSION_IMPL_CORE_EVENTS", "group__pw__impl__core.html#ga32f8301c7a43a4c4d418add1e71642a2", null ],
    [ "pw_context_create_core", "group__pw__impl__core.html#ga0a3396f78a8489f09b895eb2c03baf07", null ],
    [ "pw_context_get_default_core", "group__pw__impl__core.html#ga6e9f1110eaf106a3e6b16854e3b264fc", null ],
    [ "pw_impl_core_get_properties", "group__pw__impl__core.html#ga4aa15717cd38c5a76833d99fca494e96", null ],
    [ "pw_impl_core_get_info", "group__pw__impl__core.html#ga450513611460d0a197c4d0565e540233", null ],
    [ "pw_impl_core_update_properties", "group__pw__impl__core.html#ga6208a74739780c8852f0f586a425c90b", null ],
    [ "pw_impl_core_register", "group__pw__impl__core.html#ga7ac3070a865aadc8298211e269525b2b", null ],
    [ "pw_impl_core_destroy", "group__pw__impl__core.html#gafc5784f2824cec49236dee645b0a4f0a", null ],
    [ "pw_impl_core_get_user_data", "group__pw__impl__core.html#ga129ef0d53761693ffc2fc0d38b2c925c", null ],
    [ "pw_impl_core_get_global", "group__pw__impl__core.html#ga73468fe18802e6749578b422181c3787", null ],
    [ "pw_impl_core_add_listener", "group__pw__impl__core.html#gabed9ac3c2a65fb03b9acccf3559b0bd2", null ]
];