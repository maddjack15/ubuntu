var group__spa__string =
[
    [ "string.h", "string_8h.html", null ],
    [ "spa_strbuf", "structspa__strbuf.html", [
      [ "buffer", "structspa__strbuf.html#ad1ee23ef60728cefba6d11341da61ef1", null ],
      [ "maxsize", "structspa__strbuf.html#ac82fdbc33669185a77140a3faf908a0c", null ],
      [ "pos", "structspa__strbuf.html#a8ddb2d12b7d6a2804f13ab6c40cab6d1", null ]
    ] ],
    [ "spa_streq", "group__spa__string.html#gaccfedc485cb2e3bef649e77ee6db26ab", null ],
    [ "spa_strneq", "group__spa__string.html#ga8a13832c182bd96cdeb32e93d0a5f4cf", null ],
    [ "spa_strstartswith", "group__spa__string.html#ga0d201c72eaebf5c235c2c1790ca6da4e", null ],
    [ "spa_strendswith", "group__spa__string.html#ga7f9387d004bd1dde300f434f2987e58e", null ],
    [ "spa_atoi32", "group__spa__string.html#ga6ddf76d4003737cda2ba9b160aa8dfa8", null ],
    [ "spa_atou32", "group__spa__string.html#ga2aedff000d734290adf11899c5fcb896", null ],
    [ "spa_atoi64", "group__spa__string.html#ga1f07c2f2d56ba170bf23d472153494e5", null ],
    [ "spa_atou64", "group__spa__string.html#ga0b9d09a3a4f68c4a5e55e350caeb67fb", null ],
    [ "spa_atob", "group__spa__string.html#ga16da26e2202a32c64061f92dec72dfc5", null ],
    [ "spa_vscnprintf", "group__spa__string.html#gab9f2fbcc3c33f77f37e9f00941f387b6", null ],
    [ "spa_scnprintf", "group__spa__string.html#gae194d9bc956defbfe180dc658e3df052", null ],
    [ "spa_strtof", "group__spa__string.html#ga928368a5adc237123fe3097ddf09061d", null ],
    [ "spa_atof", "group__spa__string.html#gace4942742ce246641a3cb3b4b2540e05", null ],
    [ "spa_strtod", "group__spa__string.html#ga0faf9c1cc2f41796a16399193bbdb263", null ],
    [ "spa_atod", "group__spa__string.html#ga0b03d1967a0ee32027c1efb16fec49de", null ],
    [ "spa_dtoa", "group__spa__string.html#gae9be2db04a7f11c3ff07b78f635c9fe3", null ],
    [ "spa_strbuf_init", "group__spa__string.html#gab07cd1b0bb6923da2e15fe6eb018c7df", null ],
    [ "spa_strbuf_append", "group__spa__string.html#ga921ebca10b8f1bacd31e159f11e96288", null ]
];