var group__pw__impl__metadata =
[
    [ "impl-metadata.h", "impl-metadata_8h.html", null ],
    [ "pw_impl_metadata_events", "structpw__impl__metadata__events.html", [
      [ "version", "structpw__impl__metadata__events.html#ac11ef017d8f59e0a28d1d882ac508b22", null ],
      [ "destroy", "structpw__impl__metadata__events.html#a1f7feaad034d62902dccdef0a2b2f85a", null ],
      [ "free", "structpw__impl__metadata__events.html#a75ce933b493a16ecad3e8f9834cc74e6", null ],
      [ "property", "structpw__impl__metadata__events.html#a2a0419974291d4e9360544e5618ffb0f", null ]
    ] ],
    [ "pw_impl_metadata", "structpw__impl__metadata.html", null ],
    [ "PW_VERSION_IMPL_METADATA_EVENTS", "group__pw__impl__metadata.html#ga053df8c64585be019747bdc7c6581e1d", null ],
    [ "pw_context_create_metadata", "group__pw__impl__metadata.html#gab10f20d63d526f9117a512fbb0206b21", null ],
    [ "pw_impl_metadata_get_properties", "group__pw__impl__metadata.html#gaa6f28989938dc595ccded5afe5d0c709", null ],
    [ "pw_impl_metadata_register", "group__pw__impl__metadata.html#ga66e2fe0008d1af7533a2228663515abd", null ],
    [ "pw_impl_metadata_destroy", "group__pw__impl__metadata.html#gaf46f60e35e151a2274e3589cc15312cd", null ],
    [ "pw_impl_metadata_get_user_data", "group__pw__impl__metadata.html#ga400e2176366436ac8752c563400a8eda", null ],
    [ "pw_impl_metadata_set_implementation", "group__pw__impl__metadata.html#ga74106d1ae2eb30cee3b07a09d5e04b9d", null ],
    [ "pw_impl_metadata_get_implementation", "group__pw__impl__metadata.html#ga8bbf7f9227bbdab72bfd6f763a3e005d", null ],
    [ "pw_impl_metadata_get_global", "group__pw__impl__metadata.html#gaa37ec9146a44f5b76cde8ab427cd3b90", null ],
    [ "pw_impl_metadata_add_listener", "group__pw__impl__metadata.html#ga8b61ab446a02a2ea947bce332871d04b", null ],
    [ "pw_impl_metadata_set_property", "group__pw__impl__metadata.html#gaafe077e9b021d5f371a38e764df8f2d1", null ],
    [ "pw_impl_metadata_set_propertyf", "group__pw__impl__metadata.html#ga463c301e31c6d3e02d09c3c2e2befcdf", null ]
];