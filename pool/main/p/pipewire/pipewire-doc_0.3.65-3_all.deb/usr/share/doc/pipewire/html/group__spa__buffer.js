var group__spa__buffer =
[
    [ "alloc.h", "alloc_8h.html", null ],
    [ "buffer/buffer.h", "buffer_2buffer_8h.html", null ],
    [ "meta.h", "meta_8h.html", null ],
    [ "buffer/type-info.h", "buffer_2type-info_8h.html", null ],
    [ "spa_buffer_alloc_info", "structspa__buffer__alloc__info.html", [
      [ "flags", "structspa__buffer__alloc__info.html#afc286a004cefa1ef2d751483a8cc8c15", null ],
      [ "max_align", "structspa__buffer__alloc__info.html#a51af051b079634c3f854680f118716e7", null ],
      [ "n_metas", "structspa__buffer__alloc__info.html#a49810ff55f219eea5c1e4a3e2f24cd4c", null ],
      [ "n_datas", "structspa__buffer__alloc__info.html#aea2d60a678ae26619b5bfb35291b9a01", null ],
      [ "metas", "structspa__buffer__alloc__info.html#aef6e15022383cf49cbba4196111c190d", null ],
      [ "datas", "structspa__buffer__alloc__info.html#adea010a789fec41087739852b235185b", null ],
      [ "data_aligns", "structspa__buffer__alloc__info.html#ae0f8e64c4f71c63cfa87b1b7527a47c7", null ],
      [ "skel_size", "structspa__buffer__alloc__info.html#a963cf1755ba6612abcff0491680abc64", null ],
      [ "meta_size", "structspa__buffer__alloc__info.html#a63296028aeb53c2e98501c78f1d53617", null ],
      [ "chunk_size", "structspa__buffer__alloc__info.html#a8ea4df582a468b0f1621672af3e2426f", null ],
      [ "data_size", "structspa__buffer__alloc__info.html#a30233569ad362f458d9e1344d0b5a58c", null ],
      [ "mem_size", "structspa__buffer__alloc__info.html#a2598f62c920f42fd1ea6547968c0e2a6", null ]
    ] ],
    [ "spa_chunk", "structspa__chunk.html", [
      [ "offset", "structspa__chunk.html#ae7a889b81a5d56ff5babd521b5ce7cb7", null ],
      [ "size", "structspa__chunk.html#a73c84537a6f3a0da168f765cb3558735", null ],
      [ "stride", "structspa__chunk.html#a5a6f66c73b76acf608ef18846d539df2", null ],
      [ "flags", "structspa__chunk.html#ae77eb3c5ecf94cc2b80c306afd7a6768", null ]
    ] ],
    [ "spa_data", "structspa__data.html", [
      [ "type", "structspa__data.html#afe135d90bee247325e72ba2f33dd9864", null ],
      [ "flags", "structspa__data.html#a997e0a03014d4455fbb993c0d7aa0c82", null ],
      [ "fd", "structspa__data.html#a504188801211b4dcaae3fc2e37653752", null ],
      [ "mapoffset", "structspa__data.html#a75b63dcf6ea09c5908b8682f1696eeae", null ],
      [ "maxsize", "structspa__data.html#ae942ee4f53c1ae2b708fdea5aa334406", null ],
      [ "data", "structspa__data.html#ac4930c9bcfff1327bc57c27a436f6451", null ],
      [ "chunk", "structspa__data.html#a2ac8186060605f0c2e23d383dc702c18", null ]
    ] ],
    [ "spa_buffer", "structspa__buffer.html", [
      [ "n_metas", "structspa__buffer.html#a026a97e0dfd3a606480f436fa61e204b", null ],
      [ "n_datas", "structspa__buffer.html#adbf5510ef0707e22b19980c84b61a073", null ],
      [ "metas", "structspa__buffer.html#a9705c915e89400eaa96a1fe84209e53e", null ],
      [ "datas", "structspa__buffer.html#ad4c72bfda8875b33b7316af4bafb9560", null ]
    ] ],
    [ "spa_meta", "structspa__meta.html", [
      [ "type", "structspa__meta.html#aceb2df955f0bee0bffaa59e62e6af67d", null ],
      [ "size", "structspa__meta.html#aad98af5fa0f07981e486b6268fe9c71c", null ],
      [ "data", "structspa__meta.html#ae2198fc30f4df8e624cd06db8cfe9583", null ]
    ] ],
    [ "spa_meta_header", "structspa__meta__header.html", [
      [ "flags", "structspa__meta__header.html#a2d8eed1753e4b1649faf357f3307217d", null ],
      [ "offset", "structspa__meta__header.html#a1410208fd9ccdd153418f01d5ce12d7b", null ],
      [ "pts", "structspa__meta__header.html#aae54e5badad1945c2a49d64842df5b1f", null ],
      [ "dts_offset", "structspa__meta__header.html#af9dface8f9e761dc4025dceaa4527a45", null ],
      [ "seq", "structspa__meta__header.html#a76604c6ef39f2e3f103f6e71532205c8", null ]
    ] ],
    [ "spa_meta_region", "structspa__meta__region.html", [
      [ "region", "structspa__meta__region.html#af1fe3dd2f5fc8f7e8899b93049dfffd2", null ]
    ] ],
    [ "spa_meta_bitmap", "structspa__meta__bitmap.html", [
      [ "format", "structspa__meta__bitmap.html#aa1f903801d658ae96cbc5e624676ff71", null ],
      [ "size", "structspa__meta__bitmap.html#a6f32bc13290f583d10ea16cc1bb825da", null ],
      [ "stride", "structspa__meta__bitmap.html#ac2f340dbebb61308461ac61592b52fe0", null ],
      [ "offset", "structspa__meta__bitmap.html#abaac271d52c056bf717f25698e9690bd", null ]
    ] ],
    [ "spa_meta_cursor", "structspa__meta__cursor.html", [
      [ "id", "structspa__meta__cursor.html#a5f190ab6e828890a8c5b530cb9cae78d", null ],
      [ "flags", "structspa__meta__cursor.html#a01ee3f6baba19d1a0851a44badd819a9", null ],
      [ "position", "structspa__meta__cursor.html#a78b7805e66e52164fc8a985578b4c990", null ],
      [ "hotspot", "structspa__meta__cursor.html#a46bdd5e6f3d880a74ae602e596176028", null ],
      [ "bitmap_offset", "structspa__meta__cursor.html#a9785c5b1408d2d4c4cc053bfb67ef6c0", null ]
    ] ],
    [ "spa_meta_control", "structspa__meta__control.html", [
      [ "sequence", "structspa__meta__control.html#a906715cf9e6709fcd23de4aef7c1dd4a", null ]
    ] ],
    [ "spa_meta_busy", "structspa__meta__busy.html", [
      [ "flags", "structspa__meta__busy.html#afa6284c360957925babd30c58fdd4807", null ],
      [ "count", "structspa__meta__busy.html#af5a282aa87b7c7b44900c00155ea77f4", null ]
    ] ],
    [ "spa_meta_videotransform", "structspa__meta__videotransform.html", [
      [ "transform", "structspa__meta__videotransform.html#a92c7c86c35c37a1d7cd7f9b79b99ef6d", null ]
    ] ],
    [ "SPA_BUFFER_ALLOC_FLAG_INLINE_META", "group__spa__buffer.html#ga7822c3be602a8cb8d73db2d2292cba21", null ],
    [ "SPA_BUFFER_ALLOC_FLAG_INLINE_CHUNK", "group__spa__buffer.html#ga99166f4bdfd45c4fe83e20ebf16932f6", null ],
    [ "SPA_BUFFER_ALLOC_FLAG_INLINE_DATA", "group__spa__buffer.html#gaec7e50ee77e4bd008354c43ba865b34b", null ],
    [ "SPA_BUFFER_ALLOC_FLAG_INLINE_ALL", "group__spa__buffer.html#ga6643fbbac39f47c2141207a9b0e10e88", null ],
    [ "SPA_BUFFER_ALLOC_FLAG_NO_DATA", "group__spa__buffer.html#gab35bf4407cae70846016a2eb10288686", null ],
    [ "SPA_CHUNK_FLAG_NONE", "group__spa__buffer.html#gac7b55666bda884c3efac917e4648338b", null ],
    [ "SPA_CHUNK_FLAG_CORRUPTED", "group__spa__buffer.html#gaa81bf44471d5f53efd5976eda41985f5", null ],
    [ "SPA_CHUNK_FLAG_EMPTY", "group__spa__buffer.html#ga9d2b0477269501b2cd39bf6379c0f9fc", null ],
    [ "SPA_DATA_FLAG_NONE", "group__spa__buffer.html#ga06caf22c0de4dd09ce23d2b65863bb39", null ],
    [ "SPA_DATA_FLAG_READABLE", "group__spa__buffer.html#ga91b4675a70fd7b17d885244e0687dd07", null ],
    [ "SPA_DATA_FLAG_WRITABLE", "group__spa__buffer.html#gaa0ad9f967fc70c2635728e9ea690a537", null ],
    [ "SPA_DATA_FLAG_DYNAMIC", "group__spa__buffer.html#gab136c278867d4077904c175b638172e2", null ],
    [ "SPA_DATA_FLAG_READWRITE", "group__spa__buffer.html#ga5a6d5af42bd20e6a4f03bcb51a6dddd9", null ],
    [ "spa_meta_first", "group__spa__buffer.html#ga949ddbe7356adce20368bb371c22fe18", null ],
    [ "spa_meta_end", "group__spa__buffer.html#ga8acb71d9ab841172a406a0cb3ef88756", null ],
    [ "spa_meta_check", "group__spa__buffer.html#gaeaf6a23eedc8287e462151c68cf392d8", null ],
    [ "SPA_META_HEADER_FLAG_DISCONT", "group__spa__buffer.html#gadb856fba3c87be4a21fff5cf4e04fa75", null ],
    [ "SPA_META_HEADER_FLAG_CORRUPTED", "group__spa__buffer.html#ga34b468f6d3a1634edb99c48d7b7b9e59", null ],
    [ "SPA_META_HEADER_FLAG_MARKER", "group__spa__buffer.html#gad15ee8284bcc54823ad53acac1c8e655", null ],
    [ "SPA_META_HEADER_FLAG_HEADER", "group__spa__buffer.html#ga0d13aea5c047ef559ceee11337f46397", null ],
    [ "SPA_META_HEADER_FLAG_GAP", "group__spa__buffer.html#gac37cc6fc0c1dc3e2beeeb767d84e8a0a", null ],
    [ "SPA_META_HEADER_FLAG_DELTA_UNIT", "group__spa__buffer.html#ga839df0acd10c18d18da82786fe429cbc", null ],
    [ "spa_meta_region_is_valid", "group__spa__buffer.html#ga4c31d1224f96095267ad194b72ce7aee", null ],
    [ "spa_meta_for_each", "group__spa__buffer.html#gae1f303cee35e8a7480c7094e878a3980", null ],
    [ "spa_meta_bitmap_is_valid", "group__spa__buffer.html#gafb4a59d5cb75403df44c507e7cb53d8c", null ],
    [ "spa_meta_cursor_is_valid", "group__spa__buffer.html#gaca134139049c8556b923e55900c2e6d0", null ],
    [ "SPA_TYPE_INFO_Buffer", "group__spa__buffer.html#ga132ae3278227375c79b78642646ec0c9", null ],
    [ "SPA_TYPE_INFO_BUFFER_BASE", "group__spa__buffer.html#ga5e0cadd5ac50efb0515224adec182383", null ],
    [ "SPA_TYPE_INFO_Data", "group__spa__buffer.html#gaebb70d9cbd7c2ae9cd782216dbb51fb6", null ],
    [ "SPA_TYPE_INFO_DATA_BASE", "group__spa__buffer.html#gac32a612fa3d1978e5b82fa45fa199e33", null ],
    [ "SPA_TYPE_INFO_DATA_Fd", "group__spa__buffer.html#gae2090b468787d5a712acc82b1159fd30", null ],
    [ "SPA_TYPE_INFO_DATA_FD_BASE", "group__spa__buffer.html#ga477a819f19df92c99f9ce40308bd7f3f", null ],
    [ "SPA_TYPE_INFO_Meta", "group__spa__buffer.html#gac6d319daaf596f97eed519a41237ed6b", null ],
    [ "SPA_TYPE_INFO_META_BASE", "group__spa__buffer.html#ga96f0ecdf5c293145d116acf7e5f1d64f", null ],
    [ "SPA_TYPE_INFO_META_Array", "group__spa__buffer.html#gae3a8f97b5c95d6bc95bd2d4695b7dcf5", null ],
    [ "SPA_TYPE_INFO_META_ARRAY_BASE", "group__spa__buffer.html#ga590da1b50c996e0dedcf1f9e4cde29f5", null ],
    [ "SPA_TYPE_INFO_META_Region", "group__spa__buffer.html#ga4438d7f3591983896e7282f754837160", null ],
    [ "SPA_TYPE_INFO_META_REGION_BASE", "group__spa__buffer.html#ga3dcac15d4672320e499d25353fe3de40", null ],
    [ "SPA_TYPE_INFO_META_ARRAY_Region", "group__spa__buffer.html#gae0a9f08b948a42aff3229c3b23621a8e", null ],
    [ "SPA_TYPE_INFO_META_ARRAY_REGION_BASE", "group__spa__buffer.html#gaa00e40bcceff0a84001ac2a16e5b03e5", null ],
    [ "spa_data_type", "group__spa__buffer.html#gae56499a4188661fd69531560e4bd48bd", [
      [ "SPA_DATA_Invalid", "group__spa__buffer.html#ggae56499a4188661fd69531560e4bd48bda8880ffb8be5381b159b10e80758c7f83", null ],
      [ "SPA_DATA_MemPtr", "group__spa__buffer.html#ggae56499a4188661fd69531560e4bd48bda4fb60a9f031986db3588cef6769001eb", null ],
      [ "SPA_DATA_MemFd", "group__spa__buffer.html#ggae56499a4188661fd69531560e4bd48bda43578924a4b0d44cad1548ac459b441e", null ],
      [ "SPA_DATA_DmaBuf", "group__spa__buffer.html#ggae56499a4188661fd69531560e4bd48bdad7eda4de4665a4f1ed3abd354bc6e7b2", null ],
      [ "SPA_DATA_MemId", "group__spa__buffer.html#ggae56499a4188661fd69531560e4bd48bdabe177f1548c271a30ac503f54e649720", null ],
      [ "_SPA_DATA_LAST", "group__spa__buffer.html#ggae56499a4188661fd69531560e4bd48bda156b1c773c0fd4ce6f735e4e9bea25b7", null ]
    ] ],
    [ "spa_meta_type", "group__spa__buffer.html#gad804f6522a5dac20afe70d6311feda05", [
      [ "SPA_META_Invalid", "group__spa__buffer.html#ggad804f6522a5dac20afe70d6311feda05ad7f064f06e915f8436a9010b66ebc517", null ],
      [ "SPA_META_Header", "group__spa__buffer.html#ggad804f6522a5dac20afe70d6311feda05aaad9336dacb1c7434c420928a4f72bca", null ],
      [ "SPA_META_VideoCrop", "group__spa__buffer.html#ggad804f6522a5dac20afe70d6311feda05a9b40d22111a55620c3f56308aaefd55f", null ],
      [ "SPA_META_VideoDamage", "group__spa__buffer.html#ggad804f6522a5dac20afe70d6311feda05a11ea50939eda3aef8b9a0a080fd7d587", null ],
      [ "SPA_META_Bitmap", "group__spa__buffer.html#ggad804f6522a5dac20afe70d6311feda05a2b25b97e646f36481c9566d37fff022f", null ],
      [ "SPA_META_Cursor", "group__spa__buffer.html#ggad804f6522a5dac20afe70d6311feda05a7870f2f26da1188f19eb6edad7f2b900", null ],
      [ "SPA_META_Control", "group__spa__buffer.html#ggad804f6522a5dac20afe70d6311feda05acff876e5b1fd3767b502c0ae6e7e258c", null ],
      [ "SPA_META_Busy", "group__spa__buffer.html#ggad804f6522a5dac20afe70d6311feda05a964798527c5cb6ffa57d43b71a5bef3b", null ],
      [ "SPA_META_VideoTransform", "group__spa__buffer.html#ggad804f6522a5dac20afe70d6311feda05a59fc7770a3450c6f770bf5862f9872fb", null ],
      [ "_SPA_META_LAST", "group__spa__buffer.html#ggad804f6522a5dac20afe70d6311feda05aefff8a3623d2416a427dafe4861ae5c3", null ]
    ] ],
    [ "spa_meta_videotransform_value", "group__spa__buffer.html#gab4afeb1516aa33126757cfa275efd7a3", [
      [ "SPA_META_TRANSFORMATION_None", "group__spa__buffer.html#ggab4afeb1516aa33126757cfa275efd7a3a6f7952894050662cb5d8d2db043c2b03", null ],
      [ "SPA_META_TRANSFORMATION_90", "group__spa__buffer.html#ggab4afeb1516aa33126757cfa275efd7a3a8e9e5ad40604aeeeb55cf9e3429d3d6d", null ],
      [ "SPA_META_TRANSFORMATION_180", "group__spa__buffer.html#ggab4afeb1516aa33126757cfa275efd7a3aa237f5e00483eb05288512fdb9c81a02", null ],
      [ "SPA_META_TRANSFORMATION_270", "group__spa__buffer.html#ggab4afeb1516aa33126757cfa275efd7a3a33ba7269831b22421f8d2ce4bbe20e88", null ],
      [ "SPA_META_TRANSFORMATION_Flipped", "group__spa__buffer.html#ggab4afeb1516aa33126757cfa275efd7a3a15451e98a40c848de2222531d302967c", null ],
      [ "SPA_META_TRANSFORMATION_Flipped90", "group__spa__buffer.html#ggab4afeb1516aa33126757cfa275efd7a3a5fadaa75b986d63221569ace04d06702", null ],
      [ "SPA_META_TRANSFORMATION_Flipped180", "group__spa__buffer.html#ggab4afeb1516aa33126757cfa275efd7a3a3514763b1598ab22d91dba4e9ee4a532", null ],
      [ "SPA_META_TRANSFORMATION_Flipped270", "group__spa__buffer.html#ggab4afeb1516aa33126757cfa275efd7a3a0234145e86447c5cdbce06f9784a301c", null ]
    ] ],
    [ "spa_buffer_alloc_fill_info", "group__spa__buffer.html#ga78c4855fa1f977a81253c5fb56f3ca19", null ],
    [ "spa_buffer_alloc_layout", "group__spa__buffer.html#ga7507cafea4ff7545fa7b1ce68a91adde", null ],
    [ "spa_buffer_alloc_layout_array", "group__spa__buffer.html#ga890344a4b76e476910fde107efe427dc", null ],
    [ "spa_buffer_alloc_array", "group__spa__buffer.html#ga19c6e5afa926fbda88e8b236df740356", null ],
    [ "spa_buffer_find_meta", "group__spa__buffer.html#gaa9a9f6e02fb1ecf289e8d647be84770d", null ],
    [ "spa_buffer_find_meta_data", "group__spa__buffer.html#ga9660cb2a403a7e57860cf739396d9bf5", null ],
    [ "spa_meta_first", "group__spa__buffer.html#ga7ce30cbcea289cbb13c62b406151ac29", null ],
    [ "spa_meta_end", "group__spa__buffer.html#ga09f7c04cbfa3ccd986c9c78e4056122e", null ],
    [ "spa_meta_region_is_valid", "group__spa__buffer.html#gaa045d6139b26b993d9d4543c9c9a9406", null ],
    [ "spa_type_data_type", "group__spa__buffer.html#ga84652d3daea314168b02e07b9041e8f9", null ],
    [ "spa_type_meta_type", "group__spa__buffer.html#gae3317a3f21fe6eef3312dc4adde92c20", null ]
];