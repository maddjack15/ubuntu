var group__pw__impl__factory =
[
    [ "impl-factory.h", "impl-factory_8h.html", null ],
    [ "pw_impl_factory_events", "structpw__impl__factory__events.html", [
      [ "version", "structpw__impl__factory__events.html#a61bf0bc918867a1315f7c09e870cf297", null ],
      [ "destroy", "structpw__impl__factory__events.html#abb0d82e4263cbe36b38aa10eef130ad0", null ],
      [ "free", "structpw__impl__factory__events.html#ae608dbd84c609b5b8a6d7c232e5a569f", null ],
      [ "initialized", "structpw__impl__factory__events.html#a6bb4670f4a96e31d0f1f30d3fc763bc6", null ]
    ] ],
    [ "pw_impl_factory_implementation", "structpw__impl__factory__implementation.html", [
      [ "version", "structpw__impl__factory__implementation.html#ab63e939995687efd690f736730021e7f", null ],
      [ "create_object", "structpw__impl__factory__implementation.html#a99eef2345bd7b402f47ad72beb6ebfe7", null ]
    ] ],
    [ "pw_impl_factory", "structpw__impl__factory.html", null ],
    [ "PW_VERSION_IMPL_FACTORY_EVENTS", "group__pw__impl__factory.html#gadbe124033ba53338a076f3b2d3877faa", null ],
    [ "PW_VERSION_IMPL_FACTORY_IMPLEMENTATION", "group__pw__impl__factory.html#ga01ccdfc19815a10588afc2490f9a2524", null ],
    [ "pw_context_create_factory", "group__pw__impl__factory.html#ga75c64581b8ccb9875f299eccc390316c", null ],
    [ "pw_impl_factory_get_properties", "group__pw__impl__factory.html#gade263459999ee6d4679e9b9db96058b8", null ],
    [ "pw_impl_factory_get_info", "group__pw__impl__factory.html#ga5cdef3b520df96287b331fa5492d2b45", null ],
    [ "pw_impl_factory_update_properties", "group__pw__impl__factory.html#ga4f53dcc667ed708959ac37fc8115130f", null ],
    [ "pw_impl_factory_register", "group__pw__impl__factory.html#ga7f3c62095caa400ba058c912321d24d1", null ],
    [ "pw_impl_factory_destroy", "group__pw__impl__factory.html#ga3037016444c5228a79a246e5e7ecdbee", null ],
    [ "pw_impl_factory_get_user_data", "group__pw__impl__factory.html#gaba655c0d5d24399f7d66a494fd21cb37", null ],
    [ "pw_impl_factory_get_global", "group__pw__impl__factory.html#gaa8d3c083e63f3ff60360461438aab970", null ],
    [ "pw_impl_factory_add_listener", "group__pw__impl__factory.html#ga81032931eb91354a197a6c1de9fff956", null ],
    [ "pw_impl_factory_set_implementation", "group__pw__impl__factory.html#ga5dfe891ca9e2a49502ff700bfa4a60c7", null ],
    [ "pw_impl_factory_create_object", "group__pw__impl__factory.html#ga6d7606feeec394e2a05c61ee54484baa", null ],
    [ "pw_context_find_factory", "group__pw__impl__factory.html#ga8e467fa54066b8531ff28d4203a70f10", null ]
];