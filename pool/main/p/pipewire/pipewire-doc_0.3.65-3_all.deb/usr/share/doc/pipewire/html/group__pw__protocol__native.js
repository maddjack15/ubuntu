var group__pw__protocol__native =
[
    [ "protocol-native.h", "protocol-native_8h.html", null ],
    [ "pw_protocol_native_message", "structpw__protocol__native__message.html", [
      [ "id", "structpw__protocol__native__message.html#a32d56d90a40415a584d28262cb30941e", null ],
      [ "opcode", "structpw__protocol__native__message.html#aef6ddaa16aeaa35b4276e3b2767268aa", null ],
      [ "data", "structpw__protocol__native__message.html#a60ea6289ac35a79b83b7e1caa0c8edf6", null ],
      [ "size", "structpw__protocol__native__message.html#ad9a08cd2b12fa38a8d222308270faf40", null ],
      [ "n_fds", "structpw__protocol__native__message.html#a6c4a9b3a354cf7f37c8c4aa25de81d67", null ],
      [ "fds", "structpw__protocol__native__message.html#abaad1bc5e0c163fa89fea9c0d0852c4f", null ],
      [ "seq", "structpw__protocol__native__message.html#a45a77f421d3b6b1123b85883e28b48b3", null ]
    ] ],
    [ "pw_protocol_native_demarshal", "structpw__protocol__native__demarshal.html", [
      [ "func", "structpw__protocol__native__demarshal.html#ad4dcb55ad836d8f5cf303742aaae5ff2", null ],
      [ "permissions", "structpw__protocol__native__demarshal.html#acc4296853e8e0def46f6269326b76198", null ],
      [ "flags", "structpw__protocol__native__demarshal.html#a3f981db467091f35ddb7e5ecb2bf0705", null ]
    ] ],
    [ "pw_protocol_native_ext", "structpw__protocol__native__ext.html", [
      [ "version", "structpw__protocol__native__ext.html#a588964b2fd1a055deb2d0ab1455e3e9f", null ],
      [ "begin_proxy", "structpw__protocol__native__ext.html#a3de6ba89d6e099eee955acf2744a52da", null ],
      [ "add_proxy_fd", "structpw__protocol__native__ext.html#a356887f5340ad05b4b8ba90f26238565", null ],
      [ "get_proxy_fd", "structpw__protocol__native__ext.html#a04968e51cb5e9777795800dce3eaaa76", null ],
      [ "end_proxy", "structpw__protocol__native__ext.html#a6eb6702a7aaeaa50172d66ed9a6f818a", null ],
      [ "begin_resource", "structpw__protocol__native__ext.html#a9c23c3dab6c416b7f92e3b3684ddae88", null ],
      [ "add_resource_fd", "structpw__protocol__native__ext.html#a92709bdf1f3f815be21a33f119b0d8e6", null ],
      [ "get_resource_fd", "structpw__protocol__native__ext.html#aee24b5ce6da772ce4167bfd88a8c7cdb", null ],
      [ "end_resource", "structpw__protocol__native__ext.html#a1a348ddd739378bbd4b996ef68de2adc", null ]
    ] ],
    [ "PW_TYPE_INFO_PROTOCOL_Native", "group__pw__protocol__native.html#ga1669efe2f2eca3046316944cce89960b", null ],
    [ "PW_VERSION_PROTOCOL_NATIVE_EXT", "group__pw__protocol__native.html#gaa958b676bb34e137b25464b38ea5e9d3", null ],
    [ "pw_protocol_native_begin_proxy", "group__pw__protocol__native.html#gaa23ae719ffbe059e22a78cd87ff03b82", null ],
    [ "pw_protocol_native_add_proxy_fd", "group__pw__protocol__native.html#gabc95cd3baba011a05fb97785b32ed1d8", null ],
    [ "pw_protocol_native_get_proxy_fd", "group__pw__protocol__native.html#ga1b131d16fd8fd87139c6c1ff9692cbf8", null ],
    [ "pw_protocol_native_end_proxy", "group__pw__protocol__native.html#ga257195ab4d68a561862c0ce7550b8c54", null ],
    [ "pw_protocol_native_begin_resource", "group__pw__protocol__native.html#gac0197ba818fbf63e70a2ccd67ef3fa11", null ],
    [ "pw_protocol_native_add_resource_fd", "group__pw__protocol__native.html#gadbdccde3ca051bb0e496216d40fa0371", null ],
    [ "pw_protocol_native_get_resource_fd", "group__pw__protocol__native.html#gafd7ad8111398724f9af08d1184dbef4e", null ],
    [ "pw_protocol_native_end_resource", "group__pw__protocol__native.html#ga85f4409d2a8b300c2fd225c418b7d1aa", null ]
];