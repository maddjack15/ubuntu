/***************************************************************************
    text-pl.h  -  polskie komunikaty
                             -------------------
    begin                : Thu Jan 21 2000
    copyright            : (C) 2000 by Tomasz Patora
    email                : ajv@greebo.net
 ***************************************************************************/



/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

// messages from cutswath.c

/* 00 */ "cutswath(): nie mog� zaalokowa� danych\n",

/* 01 */ "cutswath(): nie mog� przeczyta� danych o g�rnym marginesie\n",

/* 02 */ "cutswath(): nie mog� przeczyta� danych o bocznym marginesie\n",

/* 03 */ "cutswath(): nie mog� przeczyta� nast�pnej lini\n",

/* 04 */ "cutswath(): nie mog� zaalokowa� danych ppa\n",

/* 05 */ "ppa_print_page(): b��d w wywo�aniu procedury cut_im_black_swath()\n",

/* 06 */ "ppa_print_page(): nieznany kod powrotu w switch\n",

/* 07 */ "ppa_print_page(): b��d w wywo�aniu cut_im_color_swath()\n",

/* 08 */ "make_im_stat: nie mog� otczyta� pliku gamma. Sprawdz uprawnienia dla pliku\n",
    "FATALNIE: Nieznany b��d\n"
