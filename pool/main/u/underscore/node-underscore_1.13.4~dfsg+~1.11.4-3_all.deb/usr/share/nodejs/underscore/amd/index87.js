define(['./index31'], (function (_tagTester) {

	var isError = _tagTester('Error');

	return isError;

}));
