define(['./index31'], (function (_tagTester) {

	var isSymbol = _tagTester('Symbol');

	return isSymbol;

}));
