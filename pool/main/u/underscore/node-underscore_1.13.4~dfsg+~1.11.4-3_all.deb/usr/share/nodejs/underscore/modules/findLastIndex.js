import createPredicateIndexFinder from './_createPredicateIndexFinder.js';

// Returns the last index on an array-like that passes a truth test.
export default createPredicateIndexFinder(-1);
