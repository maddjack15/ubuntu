define(['./index31'], (function (_tagTester) {

	var isString = _tagTester('String');

	return isString;

}));
