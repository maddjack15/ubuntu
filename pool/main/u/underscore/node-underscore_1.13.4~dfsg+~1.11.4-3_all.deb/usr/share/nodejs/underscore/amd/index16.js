define(['./index26'], (function (_shallowProperty) {

	// Internal helper to obtain the `length` property of an object.
	var getLength = _shallowProperty('length');

	return getLength;

}));
