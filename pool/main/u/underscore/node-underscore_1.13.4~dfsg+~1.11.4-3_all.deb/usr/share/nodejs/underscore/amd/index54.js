define(['./index7', './index14'], (function (_createEscaper, _escapeMap) {

	// Function for escaping strings to HTML interpolation.
	var escape = _createEscaper(_escapeMap);

	return escape;

}));
