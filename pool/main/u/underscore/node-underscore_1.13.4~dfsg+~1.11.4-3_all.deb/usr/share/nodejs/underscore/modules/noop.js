// Predicate-generating function. Often useful outside of Underscore.
export default function noop(){}
