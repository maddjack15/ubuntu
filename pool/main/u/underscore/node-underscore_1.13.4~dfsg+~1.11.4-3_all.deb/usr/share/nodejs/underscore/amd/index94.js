define(['./index31'], (function (_tagTester) {

	var isNumber = _tagTester('Number');

	return isNumber;

}));
