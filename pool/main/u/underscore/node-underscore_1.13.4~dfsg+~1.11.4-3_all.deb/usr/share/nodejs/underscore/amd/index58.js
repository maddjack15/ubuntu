define(['./index10'], (function (_createPredicateIndexFinder) {

	// Returns the first index on an array-like that passes a truth test.
	var findIndex = _createPredicateIndexFinder(1);

	return findIndex;

}));
