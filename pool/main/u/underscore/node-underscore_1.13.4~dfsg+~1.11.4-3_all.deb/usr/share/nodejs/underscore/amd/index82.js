define(['./index31'], (function (_tagTester) {

	var isArrayBuffer = _tagTester('ArrayBuffer');

	return isArrayBuffer;

}));
