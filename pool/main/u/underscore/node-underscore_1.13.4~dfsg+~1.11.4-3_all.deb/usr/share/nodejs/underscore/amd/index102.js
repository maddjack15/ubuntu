define(['./index31'], (function (_tagTester) {

	var isWeakSet = _tagTester('WeakSet');

	return isWeakSet;

}));
