define(['./index6', './index33'], (function (_createAssigner, allKeys) {

	// Fill in a given object with default properties.
	var defaults = _createAssigner(allKeys, true);

	return defaults;

}));
