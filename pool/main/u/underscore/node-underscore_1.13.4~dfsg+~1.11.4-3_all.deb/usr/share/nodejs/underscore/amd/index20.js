define(['./index31'], (function (_tagTester) {

	var hasObjectTag = _tagTester('Object');

	return hasObjectTag;

}));
