#ifndef ZZIP_WARNING
#define ZZIP_WARNING 1
#ifdef __GNUC__
#warning do no not use <zzip.h>, update to include <zzip/lib.h>
#else
#error   do no not use <zzip.h>, update to include <zzip/lib.h>
#endif
#endif
#include "zzip/lib.h"
