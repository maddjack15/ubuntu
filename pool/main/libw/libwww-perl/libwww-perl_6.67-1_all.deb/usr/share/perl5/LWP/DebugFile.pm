package LWP::DebugFile;

our $VERSION = '6.67';

# legacy stub

1;
