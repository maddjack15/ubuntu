#!/bin/sh

. $(dirname $0)/functions.sh
settitle

ping -c3 $server

pause
