var dpid_8h =
[
    [ "DAEMON_PID_FILE_KILL_WAIT_AVAILABLE", "dpid_8h.html#a7398a8a97f9134d4c0e258ef8249216a", null ],
    [ "daemon_pid_file_proc_t", "dpid_8h.html#af2fc940018aeeedabd2b7f0e926e539c", null ],
    [ "daemon_pid_file_create", "dpid_8h.html#a058d4fec58507c64b15fd06f34aa9bea", null ],
    [ "daemon_pid_file_is_running", "dpid_8h.html#a14d5b1ab3600f0771b2a1de11add3fb5", null ],
    [ "daemon_pid_file_kill", "dpid_8h.html#a9156802865287ccd2a49f043cb64a212", null ],
    [ "daemon_pid_file_kill_wait", "dpid_8h.html#a91b0acbb786d1aa0d721ade4c8d9bc71", null ],
    [ "daemon_pid_file_proc_default", "dpid_8h.html#af7d09b973fc135775f458e1fa9f3f2f1", null ],
    [ "daemon_pid_file_remove", "dpid_8h.html#a0d620a1d51b3863781caeaf5a99cb483", null ],
    [ "daemon_pid_file_ident", "dpid_8h.html#a432e89b3c0a2ca30fb8537cc8d684bfa", null ],
    [ "daemon_pid_file_proc", "dpid_8h.html#a6f3a973f57b266131367efc3540467e9", null ]
];