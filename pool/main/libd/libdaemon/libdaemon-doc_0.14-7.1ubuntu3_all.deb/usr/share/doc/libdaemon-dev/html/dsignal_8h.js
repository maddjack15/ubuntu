var dsignal_8h =
[
    [ "daemon_signal_done", "dsignal_8h.html#a41012e0e3938134b7b8c96179ab0b4e7", null ],
    [ "daemon_signal_fd", "dsignal_8h.html#ae9c6e11a9659be0ea1ae328dc34976c3", null ],
    [ "daemon_signal_init", "dsignal_8h.html#af80ec0109e0f8cc01d76855016812f7c", null ],
    [ "daemon_signal_install", "dsignal_8h.html#a0dc393b9243d25b088e3d18a59efda84", null ],
    [ "daemon_signal_next", "dsignal_8h.html#aa67b4ee88d0cd43058b296d18a4298bc", null ]
];