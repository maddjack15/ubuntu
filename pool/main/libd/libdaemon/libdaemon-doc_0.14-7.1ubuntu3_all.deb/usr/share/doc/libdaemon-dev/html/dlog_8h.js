var dlog_8h =
[
    [ "DAEMON_GCC_PRINTF_ATTR", "dlog_8h.html#ac83d9f3e20dd7b5065ef827ba2706425", null ],
    [ "DAEMON_LOGV_AVAILABLE", "dlog_8h.html#a52a209abd0a5e8179dc11ad9296c17cc", null ],
    [ "DAEMON_SET_VERBOSITY_AVAILABLE", "dlog_8h.html#afad238d694635b18df1c0e97b7dd7bce", null ],
    [ "daemon_log_flags", "dlog_8h.html#a711694327c80cef23d887eabb605d62d", [
      [ "DAEMON_LOG_SYSLOG", "dlog_8h.html#a711694327c80cef23d887eabb605d62da4945721202f8d7f771a92ef39b894142", null ],
      [ "DAEMON_LOG_STDERR", "dlog_8h.html#a711694327c80cef23d887eabb605d62da97129c2dc44eeb2b1061a5ca754bf2be", null ],
      [ "DAEMON_LOG_STDOUT", "dlog_8h.html#a711694327c80cef23d887eabb605d62dadfc366c253cc1a97289c20007ae8195a", null ],
      [ "DAEMON_LOG_AUTO", "dlog_8h.html#a711694327c80cef23d887eabb605d62dada2aeb6896178be4fbf78004b413df72", null ]
    ] ],
    [ "daemon_ident_from_argv0", "dlog_8h.html#af87b2c912ad651da9f1c3865d729fe7d", null ],
    [ "daemon_log", "dlog_8h.html#af5b8f451ca33301438141830949e236d", null ],
    [ "daemon_logv", "dlog_8h.html#a63055095705eb2795a15572908450e14", null ],
    [ "daemon_set_verbosity", "dlog_8h.html#a1c506933c56bdc986746a27d6b2a475e", null ],
    [ "daemon_log_ident", "dlog_8h.html#acf05b462624a66e00cdbefe14cc13098", null ],
    [ "daemon_log_use", "dlog_8h.html#a85a7b493c0d2bab5c540c1ab8fceac20", null ]
];