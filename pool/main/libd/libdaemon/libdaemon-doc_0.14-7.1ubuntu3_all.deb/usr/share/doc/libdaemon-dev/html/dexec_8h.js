var dexec_8h =
[
    [ "DAEMON_EXEC_AVAILABLE", "dexec_8h.html#ac658c8eb5e5ea183e044346a1b837ba3", null ],
    [ "DAEMON_EXECV_AVAILABLE", "dexec_8h.html#a511a195626aaa70cb6205849971dbd1a", null ],
    [ "DAEMON_GCC_SENTINEL", "dexec_8h.html#a8381f7d17726f5061c0578abfe7d7586", null ],
    [ "daemon_exec", "dexec_8h.html#aac8cbda88ecee36488b6c3583b72e02f", null ],
    [ "daemon_execv", "dexec_8h.html#ab2dd19edfaa704b69ab9d1254c436313", null ]
];