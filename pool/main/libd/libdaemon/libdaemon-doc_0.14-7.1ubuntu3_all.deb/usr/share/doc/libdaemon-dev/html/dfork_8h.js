var dfork_8h =
[
    [ "DAEMON_CLOSE_ALL_AVAILABLE", "dfork_8h.html#ab31bb2a651d11690223af635efc1680e", null ],
    [ "DAEMON_RESET_SIGS_AVAILABLE", "dfork_8h.html#a521b2139c3093e07d29fb0bd85d3ec4d", null ],
    [ "DAEMON_UNBLOCK_SIGS_AVAILABLE", "dfork_8h.html#a0ba5e509d4a342c462cf1b4d31f433ad", null ],
    [ "daemon_close_all", "dfork_8h.html#a39b5b3dba7b7d46bcbf6e26e58243ce2", null ],
    [ "daemon_close_allv", "dfork_8h.html#a2b4a8b173f5e2cfc091ee7ae1c3c3157", null ],
    [ "daemon_fork", "dfork_8h.html#addbb22c420e9d8c6afcbe68d57f38160", null ],
    [ "daemon_reset_sigs", "dfork_8h.html#a29f3da66a3014a0214a24963f4890f46", null ],
    [ "daemon_reset_sigsv", "dfork_8h.html#ac2b06590fe5a979b6a1f721099a17936", null ],
    [ "daemon_retval_done", "dfork_8h.html#a1e948bc26340d8e6e70bd733e5514809", null ],
    [ "daemon_retval_init", "dfork_8h.html#af14c5365e04c1a332dd7422b3f491efb", null ],
    [ "daemon_retval_send", "dfork_8h.html#ae85d007816541dfda04eb74125135484", null ],
    [ "daemon_retval_wait", "dfork_8h.html#ae6e21a020db036a9b4119fcd539292c7", null ],
    [ "daemon_unblock_sigs", "dfork_8h.html#a0b3e9332fce00b396dca8fa595c880d4", null ],
    [ "daemon_unblock_sigsv", "dfork_8h.html#a1caba4464f62bd0372cf488baaac1dea", null ]
];