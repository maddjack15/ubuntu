var searchData=
[
  ['evdev_20ioctls_0',['evdev ioctls',['../ioctls.html',1,'']]]
];
