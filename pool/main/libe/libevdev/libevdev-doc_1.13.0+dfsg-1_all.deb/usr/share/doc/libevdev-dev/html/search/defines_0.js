var searchData=
[
  ['libevdev_5fattribute_5fprintf_0',['LIBEVDEV_ATTRIBUTE_PRINTF',['../libevdev_8h.html#a64a0f325e88e1be50eb806e1ff75aec8',1,'libevdev.h']]],
  ['libevdev_5fdeprecated_1',['LIBEVDEV_DEPRECATED',['../libevdev_8h.html#aa136bf4638abda28de7cd9f48af534ae',1,'libevdev.h']]]
];
