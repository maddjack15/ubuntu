var searchData=
[
  ['initialization_20and_20setup_0',['Initialization and setup',['../group__init.html',1,'']]]
];
