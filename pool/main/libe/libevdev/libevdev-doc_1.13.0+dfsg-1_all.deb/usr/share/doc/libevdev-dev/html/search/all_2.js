var searchData=
[
  ['evdev_20ioctls_0',['evdev ioctls',['../ioctls.html',1,'']]],
  ['event_20handling_1',['Event handling',['../group__events.html',1,'']]]
];
