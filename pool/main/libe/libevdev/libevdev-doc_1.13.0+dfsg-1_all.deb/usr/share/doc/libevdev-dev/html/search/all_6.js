var searchData=
[
  ['miscellaneous_20helper_20functions_0',['Miscellaneous helper functions',['../group__misc.html',1,'']]],
  ['modifying_20the_20appearance_20or_20capabilities_20of_20the_20device_1',['Modifying the appearance or capabilities of the device',['../group__kernel.html',1,'']]],
  ['multi_2dtouch_20related_20functions_2',['Multi-touch related functions',['../group__mt.html',1,'']]]
];
