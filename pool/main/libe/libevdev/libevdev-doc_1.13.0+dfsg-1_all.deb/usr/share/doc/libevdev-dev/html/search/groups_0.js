var searchData=
[
  ['event_20handling_0',['Event handling',['../group__events.html',1,'']]]
];
