var exif_mnote_data_8h =
[
    [ "ExifMnoteData", "exif-mnote-data_8h.html#ad274692c704f570122329ef1ab32ed31", null ],
    [ "exif_mnote_data_count", "exif-mnote-data_8h.html#af61fbda7c717e86991b0eccf6976a5f4", null ],
    [ "exif_mnote_data_get_description", "exif-mnote-data_8h.html#a72397dfd279d52fb674a1abd5ed16ee2", null ],
    [ "exif_mnote_data_get_id", "exif-mnote-data_8h.html#a981bab235db2e156216d5cc43f48cac7", null ],
    [ "exif_mnote_data_get_name", "exif-mnote-data_8h.html#aac0686178cd4b8b5ec3b1c78b41acbf8", null ],
    [ "exif_mnote_data_get_title", "exif-mnote-data_8h.html#a9ef3bec8c131fbde32702b475025e8f2", null ],
    [ "exif_mnote_data_get_value", "exif-mnote-data_8h.html#a299e3e7c9ee3c79f3678872b8a6038c4", null ],
    [ "exif_mnote_data_load", "exif-mnote-data_8h.html#a263d51ca6b59fecb34199113b033f63f", null ],
    [ "exif_mnote_data_save", "exif-mnote-data_8h.html#a704500ea880e6727d8b4a98ff38c0a25", null ]
];