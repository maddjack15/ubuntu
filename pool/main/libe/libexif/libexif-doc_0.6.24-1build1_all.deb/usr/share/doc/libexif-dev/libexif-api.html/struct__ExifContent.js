var struct__ExifContent =
[
    [ "parent", "struct__ExifContent.html#aae965558ea5c98783c4c2418364aabea", null ]
];