var exif_gps_ifd_8h =
[
    [ "ExifGPSIfdTagInfo", "structExifGPSIfdTagInfo.html", null ]
];