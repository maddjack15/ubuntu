var exif_mem_8h =
[
    [ "ExifMem", "exif-mem_8h.html#aab8aacbc0ed6f11a1f022b7b1bf4750e", null ],
    [ "ExifMemAllocFunc", "exif-mem_8h.html#a983dbcdc43d515ef6c7dc003240ef427", null ],
    [ "ExifMemFreeFunc", "exif-mem_8h.html#a82bf96c57cc83eabdba1ad1ad0d69263", null ],
    [ "ExifMemReallocFunc", "exif-mem_8h.html#aea07644ea9dc97d5572d85ef03827f65", null ],
    [ "exif_mem_new", "exif-mem_8h.html#ad56b5b9868ea77e681a903513c3b55f3", null ],
    [ "exif_mem_new_default", "exif-mem_8h.html#acc8fd4e1a319a790581975db6f1a7233", null ],
    [ "exif_mem_ref", "exif-mem_8h.html#acedafabd958c9846ea3f908135715dcf", null ],
    [ "exif_mem_unref", "exif-mem_8h.html#adabd1345e1172ce379658cecfd3f7d70", null ]
];