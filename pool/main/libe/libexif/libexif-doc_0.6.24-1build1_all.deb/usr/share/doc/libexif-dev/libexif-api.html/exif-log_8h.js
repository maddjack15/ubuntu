var exif_log_8h =
[
    [ "ExifLog", "exif-log_8h.html#a6b225115984bb2016282923cb487f16b", null ],
    [ "ExifLogFunc", "exif-log_8h.html#ae724638edf6aa856cf28717ececd84c6", null ],
    [ "exif_log_code_get_message", "exif-log_8h.html#afcbdf4fa0b146bb0040c21b3f4969e7c", null ],
    [ "exif_log_code_get_title", "exif-log_8h.html#a342d1759ec4d86896fb24fd369e758f3", null ],
    [ "exif_log_free", "exif-log_8h.html#acd0808d6d5be73f28059797c2e2e67dc", null ],
    [ "exif_log_new", "exif-log_8h.html#a001a5e553782adb78dc6fa91728004d5", null ],
    [ "exif_log_set_func", "exif-log_8h.html#a493a369b7020265971cdaf8be9a2f6fe", null ]
];