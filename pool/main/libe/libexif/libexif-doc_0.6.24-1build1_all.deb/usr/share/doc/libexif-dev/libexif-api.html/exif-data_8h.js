var exif_data_8h =
[
    [ "_ExifData", "struct__ExifData.html", "struct__ExifData" ],
    [ "exif_data_get_entry", "exif-data_8h.html#a984540c607eb7cfce58cf34e7374ab47", null ],
    [ "ExifData", "exif-data_8h.html#ae62aab6698d7c078e38cd445ddcb8abf", null ],
    [ "ExifDataOption", "exif-data_8h.html#a324f86ac1d053b37aaee45d2cfbda96d", [
      [ "EXIF_DATA_OPTION_IGNORE_UNKNOWN_TAGS", "exif-data_8h.html#a324f86ac1d053b37aaee45d2cfbda96da37a62c4c36dfb4d533338062a4040dee", null ],
      [ "EXIF_DATA_OPTION_FOLLOW_SPECIFICATION", "exif-data_8h.html#a324f86ac1d053b37aaee45d2cfbda96dae8470cc4acd5755528f7ff36ba168023", null ],
      [ "EXIF_DATA_OPTION_DONT_CHANGE_MAKER_NOTE", "exif-data_8h.html#a324f86ac1d053b37aaee45d2cfbda96da02a9ae63a51323c42968d1612e8215e7", null ]
    ] ],
    [ "exif_data_dump", "exif-data_8h.html#abbb8951da3fd646776ee4d8685b61162", null ],
    [ "exif_data_fix", "exif-data_8h.html#a9146930a0b3ef89375790e19e1bc55b2", null ],
    [ "exif_data_foreach_content", "exif-data_8h.html#ad3b39ab4a3117ca9fd7d9a1126b5d879", null ],
    [ "exif_data_get_byte_order", "exif-data_8h.html#a2d8d50e6a9c19d28fe8192ef7cc52777", null ],
    [ "exif_data_get_data_type", "exif-data_8h.html#a4fb5dada09c9fdcab3eb7fe7e840ec84", null ],
    [ "exif_data_get_mnote_data", "exif-data_8h.html#a3781327036264237ef8dfd88c66bd399", null ],
    [ "exif_data_load_data", "exif-data_8h.html#ae3ca622e7c30ea30eca06de3a120d84f", null ],
    [ "exif_data_log", "exif-data_8h.html#af0d9d41ffeb6cd98906cd5ba5819c5ef", null ],
    [ "exif_data_new", "exif-data_8h.html#a7ff9a56ae2fe853f58f693152471e4a5", null ],
    [ "exif_data_new_from_data", "exif-data_8h.html#a839a01a9f7bf88ef92f9399e336832cf", null ],
    [ "exif_data_new_from_file", "exif-data_8h.html#abf357512a9cf7d1ef75eadef7547c227", null ],
    [ "exif_data_new_mem", "exif-data_8h.html#adc0bf3d93963caf8fd68cc9fbba2b4a5", null ],
    [ "exif_data_option_get_description", "exif-data_8h.html#a524d9a6ab6784ec8bac5329087b74e62", null ],
    [ "exif_data_option_get_name", "exif-data_8h.html#a7ba9149b6530d627f0074f48ca76fe3e", null ],
    [ "exif_data_save_data", "exif-data_8h.html#ac5700820c7d7e2a199a9170ed3833591", null ],
    [ "exif_data_set_byte_order", "exif-data_8h.html#a0cb36f43b46dabad15aca7378eefe75a", null ],
    [ "exif_data_set_data_type", "exif-data_8h.html#abe6f9020e02df0d550545b50ddcafe24", null ],
    [ "exif_data_set_option", "exif-data_8h.html#af3fd819c29391da3b444cc347b86a3d4", null ],
    [ "exif_data_unset_option", "exif-data_8h.html#abe62de8c8f5a24f8847e65ca3a098da8", null ]
];