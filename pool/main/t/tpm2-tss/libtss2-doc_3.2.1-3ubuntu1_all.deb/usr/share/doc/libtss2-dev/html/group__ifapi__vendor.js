var group__ifapi__vendor =
[
    [ "ifapi_get_intl_ek_certificate", "group__ifapi__vendor.html#ga8ba591d0534628e22c038cffc64810fb", null ]
];