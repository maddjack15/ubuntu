var group___esys___set_algorithm_set =
[
    [ "Esys_SetAlgorithmSet", "group___esys___set_algorithm_set.html#gaaa8dffcd7843138023c883a89524b16b", null ],
    [ "Esys_SetAlgorithmSet_Async", "group___esys___set_algorithm_set.html#ga0fae4b9c4123a7c5e4ad1846b7f38d78", null ],
    [ "Esys_SetAlgorithmSet_Finish", "group___esys___set_algorithm_set.html#gace6f096268335cde98146b3d944f8a0b", null ]
];