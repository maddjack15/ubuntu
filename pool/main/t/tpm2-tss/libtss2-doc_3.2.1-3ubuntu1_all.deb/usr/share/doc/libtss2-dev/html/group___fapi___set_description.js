var group___fapi___set_description =
[
    [ "Fapi_SetDescription", "group___fapi___set_description.html#ga6e115a82e9a9fa2ffb325c64e44da88b", null ],
    [ "Fapi_SetDescription_Async", "group___fapi___set_description.html#gace039b4daf9996351c9772de126e1675", null ],
    [ "Fapi_SetDescription_Finish", "group___fapi___set_description.html#ga7329d6bffd1ecba011c5cb75b23f8184", null ]
];