var group__ifapi__policy__store =
[
    [ "ifapi_policy_delete", "group__ifapi__policy__store.html#ga6b07606fadbb472500535967906ddb3a", null ],
    [ "ifapi_policy_store_initialize", "group__ifapi__policy__store.html#ga16170318e9a0285005eafae1d6353095", null ],
    [ "ifapi_policy_store_load_async", "group__ifapi__policy__store.html#gae430358d72f3698c3d4b18fa06a8a814", null ],
    [ "ifapi_policy_store_load_finish", "group__ifapi__policy__store.html#ga5fe974bfecb7c370ce346c8a114114b1", null ],
    [ "ifapi_policy_store_store_async", "group__ifapi__policy__store.html#gab1b62e41f499bff4afa57b3b2465cd9b", null ],
    [ "ifapi_policy_store_store_finish", "group__ifapi__policy__store.html#gadbd9202de417606577e9cbc21cf5d773", null ]
];