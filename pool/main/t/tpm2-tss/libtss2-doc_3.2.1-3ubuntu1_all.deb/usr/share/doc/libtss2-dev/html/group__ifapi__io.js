var group__ifapi__io =
[
    [ "ifapi_io_check_file_writeable", "group__ifapi__io.html#ga7197784e25b06357ff6a77bdf79d2f8c", null ],
    [ "ifapi_io_dirfiles", "group__ifapi__io.html#ga40c91a5a75565d079801c2fbc6a0537c", null ],
    [ "ifapi_io_dirfiles_all", "group__ifapi__io.html#ga042e89f444f50e79e93133fe2419fa9d", null ],
    [ "ifapi_io_path_exists", "group__ifapi__io.html#gaddcf6927532a647297142d304d994ab8", null ],
    [ "ifapi_io_poll", "group__ifapi__io.html#ga091222f9b5420e0ba779cf09309bea8a", null ],
    [ "ifapi_io_poll_handles", "group__ifapi__io.html#ga81ca6a5c7dd8c97d6eefcd425faddb54", null ],
    [ "ifapi_io_read_async", "group__ifapi__io.html#gac846b38f5d38efeffca5c797b6079ba6", null ],
    [ "ifapi_io_read_finish", "group__ifapi__io.html#ga7c1e9c87888b39024f388bacd3745b2f", null ],
    [ "ifapi_io_remove_file", "group__ifapi__io.html#gac71d7c2f3a426f303f61f2a02a62fdca", null ],
    [ "ifapi_io_write_async", "group__ifapi__io.html#ga4a7a36449b735a6e0d32515bd77444af", null ],
    [ "ifapi_io_write_finish", "group__ifapi__io.html#ga11895786ad4495b81c8b0728dcae69bf", null ]
];