var group___esys___n_v___define_space =
[
    [ "Esys_NV_DefineSpace", "group___esys___n_v___define_space.html#gad75fc3feb15facae6f5b864bfb129bae", null ],
    [ "Esys_NV_DefineSpace_Async", "group___esys___n_v___define_space.html#ga1289f341f4c767952b631484ba0630f8", null ],
    [ "Esys_NV_DefineSpace_Finish", "group___esys___n_v___define_space.html#gac5287b2e4a4b7ed5a07c8a558afeb8e2", null ]
];