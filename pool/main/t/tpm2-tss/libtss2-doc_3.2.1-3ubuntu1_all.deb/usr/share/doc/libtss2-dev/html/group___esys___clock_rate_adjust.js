var group___esys___clock_rate_adjust =
[
    [ "Esys_ClockRateAdjust", "group___esys___clock_rate_adjust.html#gae415cd0e329ab82d53b61770c98b204d", null ],
    [ "Esys_ClockRateAdjust_Async", "group___esys___clock_rate_adjust.html#gaacb41ed3f932cd1f101e2b8ef5852fbb", null ],
    [ "Esys_ClockRateAdjust_Finish", "group___esys___clock_rate_adjust.html#ga1e30e387ebdf1a36280ba45a35b0b24b", null ]
];