var group__ifapi__policy__util__exec =
[
    [ "ifapi_policyutil_execute", "group__ifapi__policy__util__exec.html#ga3b790955343fdede4cf01a6c83a00326", null ],
    [ "ifapi_policyutil_execute_prepare", "group__ifapi__policy__util__exec.html#ga1b1daaa24f0f97e04f8535867eb17ab8", null ]
];