var group___fapi___get_poll_handles =
[
    [ "Fapi_GetPollHandles", "group___fapi___get_poll_handles.html#gad577bc25e583557ded890bacd4c6c208", null ]
];