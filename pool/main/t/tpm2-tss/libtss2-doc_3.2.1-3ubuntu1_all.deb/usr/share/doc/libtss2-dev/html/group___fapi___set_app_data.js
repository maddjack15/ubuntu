var group___fapi___set_app_data =
[
    [ "Fapi_SetAppData", "group___fapi___set_app_data.html#gabd35466b1243a45e8c0f76a5699a3027", null ],
    [ "Fapi_SetAppData_Async", "group___fapi___set_app_data.html#ga854396891225869b202aa6447893cb4c", null ],
    [ "Fapi_SetAppData_Finish", "group___fapi___set_app_data.html#ga5ec7574e08b460cb838aa570c31e6e39", null ]
];