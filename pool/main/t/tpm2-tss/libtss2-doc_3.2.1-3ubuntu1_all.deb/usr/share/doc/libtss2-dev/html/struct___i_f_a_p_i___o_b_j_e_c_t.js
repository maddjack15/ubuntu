var struct___i_f_a_p_i___o_b_j_e_c_t =
[
    [ "authorization_state", "struct___i_f_a_p_i___o_b_j_e_c_t.html#a2d594628f7b89f4b8139061b9bf496e5", null ],
    [ "handle", "struct___i_f_a_p_i___o_b_j_e_c_t.html#abaf43ce7ecd08358b1d972094f69c15b", null ],
    [ "misc", "struct___i_f_a_p_i___o_b_j_e_c_t.html#ae48d42a4fc556ae30137e27ce3b0ac49", null ],
    [ "objectType", "struct___i_f_a_p_i___o_b_j_e_c_t.html#af69f7523f69b80030b529ab47cf269de", null ],
    [ "rel_path", "struct___i_f_a_p_i___o_b_j_e_c_t.html#addac8b4fac065c2c8cf1c931d50b0ef6", null ],
    [ "system", "struct___i_f_a_p_i___o_b_j_e_c_t.html#a01936a3a431d83da3ad3e9c2914a563c", null ]
];