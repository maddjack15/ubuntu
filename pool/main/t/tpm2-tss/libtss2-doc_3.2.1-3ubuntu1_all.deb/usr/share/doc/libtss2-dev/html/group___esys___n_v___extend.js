var group___esys___n_v___extend =
[
    [ "Esys_NV_Extend", "group___esys___n_v___extend.html#ga6b751c03532d8b593ab9928129bc7442", null ],
    [ "Esys_NV_Extend_Async", "group___esys___n_v___extend.html#ga0f57aecdd575a434306f4003e33a36a5", null ],
    [ "Esys_NV_Extend_Finish", "group___esys___n_v___extend.html#ga627c7b8ac88c6d7459e8049943dfb3e6", null ]
];