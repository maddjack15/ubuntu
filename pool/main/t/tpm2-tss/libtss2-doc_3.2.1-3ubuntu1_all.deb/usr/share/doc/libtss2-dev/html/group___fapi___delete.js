var group___fapi___delete =
[
    [ "Fapi_Delete", "group___fapi___delete.html#ga6ce94794bed59ca21054e1e87ad31efd", null ],
    [ "Fapi_Delete_Async", "group___fapi___delete.html#gaefad673348f2732244537435fc0b7c1a", null ],
    [ "Fapi_Delete_Finish", "group___fapi___delete.html#ga3a911545804d3b94172f48f752350aa3", null ]
];