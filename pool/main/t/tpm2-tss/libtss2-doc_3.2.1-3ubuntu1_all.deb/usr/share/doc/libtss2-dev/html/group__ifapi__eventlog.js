var group__ifapi__eventlog =
[
    [ "ifapi_cleanup_event", "group__ifapi__eventlog.html#ga5e89f103600a23fe7cd4b6dd4dc99ddd", null ],
    [ "ifapi_eventlog_append_check", "group__ifapi__eventlog.html#ga6ac8c0daf0f029cd3696a86d68c73219", null ],
    [ "ifapi_eventlog_append_finish", "group__ifapi__eventlog.html#ga417170e7828a2ce3c141b87dbec6ca1d", null ],
    [ "ifapi_eventlog_get_async", "group__ifapi__eventlog.html#ga9677fd20dc24c0bc3ddb4492aaac529d", null ],
    [ "ifapi_eventlog_get_finish", "group__ifapi__eventlog.html#ga14c309bed3daccc393ac644c28e32efa", null ],
    [ "ifapi_eventlog_initialize", "group__ifapi__eventlog.html#gab2ade1bd7663318c8ff39f3bed986ff3", null ]
];