var group___fapi___initialize =
[
    [ "Fapi_Initialize", "group___fapi___initialize.html#ga4b586d875d32254a7d83cbb1c81066cc", null ],
    [ "Fapi_Initialize_Async", "group___fapi___initialize.html#ga493de8d930324a4620d689061af84c4f", null ],
    [ "Fapi_Initialize_Finish", "group___fapi___initialize.html#gae69689fd6f767ab2eef53e45d2afef1b", null ]
];