var group___esys___p_c_r___allocate =
[
    [ "Esys_PCR_Allocate", "group___esys___p_c_r___allocate.html#ga238cb7f2ad0ade389b50b269f78dfe26", null ],
    [ "Esys_PCR_Allocate_Async", "group___esys___p_c_r___allocate.html#ga4369e6f6c68f7033fee2647f68bf689a", null ],
    [ "Esys_PCR_Allocate_Finish", "group___esys___p_c_r___allocate.html#gab3f57f026044df8259e31882abc2f885", null ]
];