var group___esys___set_primary_policy =
[
    [ "Esys_SetPrimaryPolicy", "group___esys___set_primary_policy.html#ga3e25a9ba60f0465708ec26a8a59c05db", null ],
    [ "Esys_SetPrimaryPolicy_Async", "group___esys___set_primary_policy.html#ga6c2b949fb2f595384f147e4036ebd038", null ],
    [ "Esys_SetPrimaryPolicy_Finish", "group___esys___set_primary_policy.html#ga5e2813740b0c8b7858f2e390cc9caefa", null ]
];