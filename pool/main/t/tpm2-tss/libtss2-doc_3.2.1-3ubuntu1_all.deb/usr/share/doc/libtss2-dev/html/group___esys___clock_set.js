var group___esys___clock_set =
[
    [ "Esys_ClockSet", "group___esys___clock_set.html#gacb139a7472559f8d844f317146dda781", null ],
    [ "Esys_ClockSet_Async", "group___esys___clock_set.html#gaa550c35820ec440dc03c5e4017c775c9", null ],
    [ "Esys_ClockSet_Finish", "group___esys___clock_set.html#ga19a31097acd6d6003979bbd275d39a48", null ]
];