var group___esys___n_v___global_write_lock =
[
    [ "Esys_NV_GlobalWriteLock", "group___esys___n_v___global_write_lock.html#gad30dfeeab2e91306cf3cdd1b1c6d9963", null ],
    [ "Esys_NV_GlobalWriteLock_Async", "group___esys___n_v___global_write_lock.html#gaca9c4dc191f328535b8e933452100ba8", null ],
    [ "Esys_NV_GlobalWriteLock_Finish", "group___esys___n_v___global_write_lock.html#ga2545f1217a3f34b902c44717dad86d9b", null ]
];