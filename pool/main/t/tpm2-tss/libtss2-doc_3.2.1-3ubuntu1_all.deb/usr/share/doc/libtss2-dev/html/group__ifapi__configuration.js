var group__ifapi__configuration =
[
    [ "ifapi_config_initialize_async", "group__ifapi__configuration.html#ga989f3cb142db689a98cb0a98959badbc", null ],
    [ "ifapi_config_initialize_finish", "group__ifapi__configuration.html#ga6ab46258a0124cfedb42d3a736da8f19", null ]
];