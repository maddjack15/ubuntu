var group___fapi___get_description =
[
    [ "Fapi_GetDescription", "group___fapi___get_description.html#ga0b07d847aa3288ac8d5b1892160e65f2", null ],
    [ "Fapi_GetDescription_Async", "group___fapi___get_description.html#ga4575d9d7826346148b77487507d5be41", null ],
    [ "Fapi_GetDescription_Finish", "group___fapi___get_description.html#ga0d532752438ba5f43a5a5a2f0bfb60f3", null ]
];